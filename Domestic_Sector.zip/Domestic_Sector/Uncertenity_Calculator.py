import pandas as pd
import numpy as np
import itertools
import os
import rasterio
from rasterio.warp import reproject, Resampling
from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import cpu_count

# CONFIGURATION
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_PATH = os.path.join(BASE_DIR, "Domestic_Data_Set.xlsx")
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")

# Paths for consumption calculation
URBAN_RURAL_BASE_PATH = os.path.join(BASE_DIR, "Spatial_Data", "GHSL_urban_rural_3arcsec")
URBAN_VALUE_MAX = 30
URBAN_VALUE_MIN = 10
REGION_MASKS_PATH = os.path.join(BASE_DIR, "Spatial_Data", "Region_Masks")
POP_RASTER_PATH = os.path.join(BASE_DIR, "Spatial_Data", "Population_Rasters_Clipped")

# Consumption calculation parameters
NRW_DEFAULT = 30  # Default NRW value if missing
URBAN_CONSTANT_RANGE = (0.1, 0.5)  # Urban: 0.1, Rural: 0.5

# Enable/disable consumption uncertainty calculation
CALCULATE_CONSUMPTION = False  # Set to True to calculate consumption uncertainty
PARALLEL_PROCESSING = True
MAX_WORKERS = cpu_count() - 2

# Columns available per parameter
PARAMETER_COLUMNS = {
    'GDP': ['GDP_2021_PPP_WB', 'GDP_per_capita_stat', 'GDP_Per_Capita_IMF2_2021contant_ppp'],
    'HouseholdSize': ['HouseholdSize'],
    'Pipe': ['Pipe'],
    'NRW': ['NRW']  # Add NRW for consumption calculation
}

# Population columns for LCD calculation
POPULATION_COLUMNS = ['Population_WB', 'Pop_National_Statistics', 'Pop_US_Census']

YEARS_TO_PROCESS = list(range(1990, 2025))
SAUDI_REGIONS = ['Riyadh','Makkah','Madinah','Eastern Province','Qasim','Asir','Tabuk',
                 'Hael','Jazan','Najran','Baha','Jouf','Northern Boarders']

# HELPER FUNCTIONS FOR CONSUMPTION
def safe_div(a, b, fill=np.nan):
    """Safe division with NaN handling"""
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        out = np.divide(a, b, out=np.full_like(a, fill, dtype=float), where=(b!=0))
        if out.size == 1:
            return float(out)
        return out
    except Exception:
        return fill

def gdp_sigmoid(inf_gdp):
    """Sigmoid function for GDP to LCD conversion"""
    return 50 + 450 / (1 + np.exp(-2.06550308 * ((inf_gdp / 100000) - 0.65103896)))

def get_urban_rural_constant(urban_value):
    """Calculate consumption constant based on urban/rural cell value"""
    if np.isnan(urban_value):
        return 0.5  # Default to rural for NaN

    # Clamp values to [10, 30] range
    clamped_value = np.clip(urban_value, URBAN_VALUE_MIN, URBAN_VALUE_MAX)

    # Linear interpolation between (10, 0.5) and (30, 0.1)
    return 0.5 + (clamped_value - URBAN_VALUE_MIN) * (0.1 - 0.5) / (URBAN_VALUE_MAX - URBAN_VALUE_MIN)

# Vectorized version for efficiency
get_urban_rural_constant_vectorized = np.vectorize(get_urban_rural_constant)

def load_urban_raster(year, target_profile):
    """Load and resample urban raster for a given year"""
    urban_path = os.path.join(URBAN_RURAL_BASE_PATH, f"urban_{year}.tif")

    if not os.path.exists(urban_path):
        print(f"  Urban raster not found for {year}: {urban_path}")
        return None

    try:
        with rasterio.open(urban_path) as src:
            # Read data
            data = src.read(1).astype(np.float32)

            # Create output array
            resampled = np.zeros((target_profile['height'], target_profile['width']), dtype=np.float32)

            # Handle NaN values in source
            data_nodata = data.copy()
            if src.nodata is not None:
                data_nodata[data == src.nodata] = np.nan

            # Reproject to target grid
            reproject(
                source=data_nodata,
                destination=resampled,
                src_transform=src.transform,
                src_crs=src.crs,
                dst_transform=target_profile['transform'],
                dst_crs=target_profile['crs'],
                resampling=Resampling.bilinear
            )

            return resampled

    except Exception as e:
        print(f"  Error loading urban raster for {year}: {e}")
        return None

def load_region_mask(region_name, target_profile):
    """Load region mask raster"""
    mask_path = os.path.join(REGION_MASKS_PATH, f"{region_name}.tif")

    if not os.path.exists(mask_path):
        print(f"  Mask not found for {region_name}: {mask_path}")
        return None

    try:
        with rasterio.open(mask_path) as src:
            data = src.read(1).astype(np.float32)

            # Create output array
            resampled = np.zeros((target_profile['height'], target_profile['width']), dtype=np.float32)

            # Reproject
            reproject(
                source=data,
                destination=resampled,
                src_transform=src.transform,
                src_crs=src.crs,
                dst_transform=target_profile['transform'],
                dst_crs=target_profile['crs'],
                resampling=Resampling.nearest
            )

            return resampled > 0  # Return boolean mask

    except Exception as e:
        print(f"  Error loading mask for {region_name}: {e}")
        return None

def load_population_raster(year):
    """Load population raster for a given year"""
    pop_path = os.path.join(POP_RASTER_PATH, f"pop{year}_clipped.tif")

    if not os.path.exists(pop_path):
        print(f"  Population raster not found for {year}: {pop_path}")
        return None, None

    try:
        with rasterio.open(pop_path) as src:
            pop_data = src.read(1).astype(np.float32)
            pop_profile = src.profile

            # Replace NaN with 0
            pop_data = np.where(np.isnan(pop_data), 0, pop_data)

            return pop_data, pop_profile

    except Exception as e:
        print(f"  Error loading population raster for {year}: {e}")
        return None, None

def calculate_consumption_for_combination(args):
    """Calculate consumption for a specific parameter combination (parallel processing)"""
    year, region_name, lcd_pred, nrw_value, pop_data, pop_profile, urban_data, region_mask = args

    try:
        # Step 1: Calculate withdrawal
        withdrawal_raster = lcd_pred * pop_data * 365 / 1000  # m³/year

        # Step 2: Apply NRW factor
        nrw_factor = 1 - (nrw_value / 100)
        after_nrw_raster = withdrawal_raster * nrw_factor

        # Step 3: Apply urban/rural constant
        if urban_data is not None:
            # Extract urban data for region
            urban_in_region = urban_data[region_mask]

            if urban_in_region.size > 0:
                # Calculate constants for region only
                urban_constants = get_urban_rural_constant_vectorized(urban_in_region)

                # Create full raster
                urban_constant_raster = np.zeros_like(after_nrw_raster, dtype=np.float32)
                urban_constant_raster[region_mask] = urban_constants

                # Calculate consumption
                consumption_raster = after_nrw_raster * urban_constant_raster
            else:
                consumption_raster = after_nrw_raster * 0.3  # Default if no urban data
        else:
            consumption_raster = after_nrw_raster * 0.3  # Default if no urban raster

        # Set non-region areas to 0
        consumption_raster = np.where(region_mask, consumption_raster, 0)

        # Calculate total consumption
        total_consumption = np.sum(consumption_raster[region_mask])
        total_withdrawal = np.sum(withdrawal_raster[region_mask])

        return {
            'region': region_name,
            'year': year,
            'total_consumption': total_consumption,
            'total_withdrawal': total_withdrawal,
            'success': True
        }

    except Exception as e:
        print(f"  Error calculating consumption for {region_name} {year}: {e}")
        return {
            'region': region_name,
            'year': year,
            'success': False,
            'error': str(e)
        }

# MAIN FUNCTION WITH CONSUMPTION UNCERTAINTY
def main():
    print("="*80)
    print("WATER DEMAND UNCERTAINTY ANALYSIS WITH CONSUMPTION CALCULATION")
    print("="*80)

    # Load Excel
    df = pd.read_excel(INPUT_PATH)
    df.columns = df.columns.str.strip()
    df['Year'] = df['Year'].astype(int)
    df = df[df['Year'].isin(YEARS_TO_PROCESS)]

    # Handle NRW column - fill missing with default
    if 'NRW' not in df.columns:
        print("NRW column not found, using default value of 30%")
        df['NRW'] = NRW_DEFAULT
    else:
        df['NRW'] = pd.to_numeric(df['NRW'], errors='coerce').fillna(NRW_DEFAULT)

    # Create base output with LCD columns
    out_df = df[['Region', 'Year', 'LiterCapitaDay', 'NRW']].copy()

    # Step 1: Create LCD columns from water column
    print("\nStep 1: Processing LCD columns from water data...")

    if 'water' in df.columns:
        print(f"  Found 'water' column with {df['water'].notna().sum()} non-null values")

        for i, pop_col in enumerate(POPULATION_COLUMNS, 1):
            lcd_col_name = f"LCD_{i}"

            if pop_col in df.columns:
                print(f"  Creating {lcd_col_name} = water / {pop_col}")
                out_df[lcd_col_name] = np.nan

                mask = df['water'].notna() & df[pop_col].notna() & (df[pop_col] != 0)

                if mask.any():
                    out_df.loc[mask, lcd_col_name] = df.loc[mask, 'water'] / df.loc[mask, pop_col]
            else:
                out_df[lcd_col_name] = np.nan
    else:
        for i in range(1, 4):
            out_df[f"LCD_{i}"] = np.nan

    # All possible parameter combinations
    gdp_cols = PARAMETER_COLUMNS.get('GDP', [])
    hh_cols = PARAMETER_COLUMNS.get('HouseholdSize', [])
    pipe_cols = PARAMETER_COLUMNS.get('Pipe', [])
    nrw_cols = PARAMETER_COLUMNS.get('NRW', ['NRW'])

    all_combinations = list(itertools.product(gdp_cols, hh_cols, pipe_cols))

    # Split data
    saudi_df = df[df['Region'] == 'Saudi'].copy()
    other_countries_df = df[(df['Region'] != 'Saudi') & (df['Relation'] == 'No')].copy()
    saudi_regions_df = df[df['Region'].isin(SAUDI_REGIONS)].copy()

    # Store all predictions
    saudi_predictions = {}
    region_predictions = {}

    # Create consumption results storage
    consumption_results = {}

    # Process each GDP combination for withdrawal predictions
    print("\nStep 2: Generating withdrawal predictions for each parameter combination...")

    for i, (gdp_col, hh_col, pipe_col) in enumerate(all_combinations, 1):
        pred_col = f"P_{i}"
        combination_name = f"GDP-{gdp_col}_HH-{hh_col}_Pipe-{pipe_col}"
        print(f"\n  Processing combination {pred_col}: {combination_name}")

        # Initialize storage
        saudi_predictions[pred_col] = {}

        # Step 2.1: Saudi country-level prediction
        saudi_rows = saudi_df.sort_values('Year').copy()
        base_year = 2020 if 2020 in saudi_rows['Year'].values else saudi_rows['Year'].max()
        base_row = saudi_rows[saudi_rows['Year'] == base_year].iloc[0]

        lcd_base = base_row['LiterCapitaDay']
        if pd.isna(lcd_base):
            if pd.notna(base_row[gdp_col]):
                lcd_base = gdp_sigmoid(base_row[gdp_col])
            else:
                lcd_base = saudi_rows['LiterCapitaDay'].median()

        # Calculate predictions for Saudi
        saudi_pred_data = []
        for idx, row in saudi_rows.iterrows():
            hh_ratio = safe_div(base_row[hh_col], row[hh_col])
            gdp_ratio = safe_div(row[gdp_col], base_row[gdp_col])
            ##########################################################################
            lcd_pred = lcd_base * ((hh_ratio**0.5) * (gdp_ratio**0.5))
            ##########################################################################
            saudi_predictions[pred_col][row['Year']] = lcd_pred
            saudi_pred_data.append({
                'Region': 'Saudi',
                'Year': row['Year'],
                pred_col: lcd_pred
            })

        # Create Saudi predictions dataframe
        saudi_pred_df = pd.DataFrame(saudi_pred_data)
        out_df = pd.merge(out_df, saudi_pred_df, on=['Region', 'Year'], how='left')

        # Step 2.2: Other countries
        other_pred_data = []
        for country in other_countries_df['Region'].unique():
            c_rows = other_countries_df[other_countries_df['Region'] == country].sort_values('Year').copy()
            base_year_c = 2020 if 2020 in c_rows['Year'].values else c_rows['Year'].max()
            base_row_c = c_rows[c_rows['Year'] == base_year_c].iloc[0]

            lcd_base_c = base_row_c['LiterCapitaDay']
            if pd.isna(lcd_base_c):
                if pd.notna(base_row_c[gdp_col]):
                    lcd_base_c = gdp_sigmoid(base_row_c[gdp_col])
                else:
                    lcd_base_c = c_rows['LiterCapitaDay'].median()

            for idx, row in c_rows.iterrows():
                hh_ratio = safe_div(base_row_c[hh_col], row[hh_col])
                gdp_ratio = safe_div(row[gdp_col], base_row_c[gdp_col])
                lcd_pred = lcd_base_c * ((hh_ratio**0.5) * (gdp_ratio**0.5))

                other_pred_data.append({
                    'Region': country,
                    'Year': row['Year'],
                    pred_col: lcd_pred
                })

        # Add other countries predictions
        if other_pred_data:
            other_pred_df = pd.DataFrame(other_pred_data)
            out_df = pd.merge(out_df, other_pred_df, on=['Region', 'Year'], how='left', suffixes=('', '_other'))

            # Handle duplicate columns
            for col in out_df.columns:
                if col.endswith('_other'):
                    original_col = col.replace('_other', '')
                    if original_col in out_df.columns:
                        mask = out_df[original_col].isna()
                        out_df.loc[mask, original_col] = out_df.loc[mask, col]
                        out_df = out_df.drop(columns=[col])

        # Step 2.3: Initial Saudi regions prediction
        if pred_col not in region_predictions:
            region_predictions[pred_col] = {}

        region_pred_data = []
        for idx, row in saudi_regions_df.iterrows():
            year = row['Year']
            region = row['Region']

            # Get Saudi prediction for this year
            lcd_saudi_base = saudi_predictions[pred_col].get(year, np.nan)

            if pd.notna(lcd_saudi_base):
                hh_ratio = safe_div(base_row[hh_col] , row[hh_col])
                pipe_ratio = safe_div(row[pipe_col], base_row[pipe_col])
                ###################################################################################
                lcd_region = lcd_saudi_base * ((hh_ratio) * (pipe_ratio))
                ###################################################################################

                # Store for normalization
                if region not in region_predictions[pred_col]:
                    region_predictions[pred_col][region] = {}
                region_predictions[pred_col][region][year] = lcd_region

                # Store in temporary column
                region_pred_data.append({
                    'Region': region,
                    'Year': year,
                    f"{pred_col}_temp": lcd_region
                })

        # Add temporary region predictions
        if region_pred_data:
            region_temp_df = pd.DataFrame(region_pred_data)
            out_df = pd.merge(out_df, region_temp_df, on=['Region', 'Year'], how='left')

    print("\nStep 3: Normalizing Saudi regions for each population source...")

    # Normalize Saudi regions for each population source
    for i, pred_col in enumerate(['P_1', 'P_2', 'P_3'], 1):
        if pred_col not in saudi_predictions:
            continue

        for pop_idx, pop_col in enumerate(POPULATION_COLUMNS, 1):
            if pop_col not in df.columns:
                continue

            norm_col = f"{pred_col}R{pop_idx}"
            print(f"  Processing {norm_col} using population {pop_col}")

            # Get population data
            saudi_pop_data = {}
            for year in YEARS_TO_PROCESS:
                saudi_pop_row = saudi_df[saudi_df['Year'] == year]
                if not saudi_pop_row.empty and pop_col in saudi_pop_row.columns:
                    saudi_pop_val = saudi_pop_row[pop_col].iloc[0]
                    saudi_pop_data[year] = saudi_pop_val if pd.notna(saudi_pop_val) else np.nan

            region_pop_data = {}
            for region in SAUDI_REGIONS:
                region_pop_data[region] = {}
                region_rows = saudi_regions_df[saudi_regions_df['Region'] == region]
                for year in YEARS_TO_PROCESS:
                    year_row = region_rows[region_rows['Year'] == year]
                    if not year_row.empty and pop_col in year_row.columns:
                        pop_val = year_row[pop_col].iloc[0]
                        region_pop_data[region][year] = pop_val if pd.notna(pop_val) else np.nan

            # Calculate normalization
            norm_data = []
            for year in YEARS_TO_PROCESS:
                saudi_lcd = saudi_predictions[pred_col].get(year, np.nan)
                saudi_pop = saudi_pop_data.get(year, np.nan)

                if pd.isna(saudi_lcd) or pd.isna(saudi_pop) or saudi_pop == 0:
                    norm_factor = 1.0
                else:
                    saudi_total_water = saudi_lcd * saudi_pop
                    regional_water_sum = 0

                    for region in SAUDI_REGIONS:
                        region_lcd = region_predictions[pred_col].get(region, {}).get(year, np.nan)
                        region_pop = region_pop_data.get(region, {}).get(year, np.nan)

                        if pd.notna(region_lcd) and pd.notna(region_pop):
                            regional_water_sum += region_lcd * region_pop

                    if regional_water_sum > 0:
                        norm_factor = saudi_total_water / regional_water_sum
                    else:
                        norm_factor = 1.0

                # Apply to regions
                for region in SAUDI_REGIONS:
                    region_lcd = region_predictions[pred_col].get(region, {}).get(year, np.nan)
                    if pd.notna(region_lcd):
                        norm_lcd = region_lcd * norm_factor
                        norm_data.append({
                            'Region': region,
                            'Year': year,
                            norm_col: norm_lcd
                        })

            # Add normalized predictions
            if norm_data:
                norm_df = pd.DataFrame(norm_data)
                out_df = pd.merge(out_df, norm_df, on=['Region', 'Year'], how='left')

    # NEW: CONSUMPTION UNCERTAINTY CALCULATION
    if CALCULATE_CONSUMPTION:
        print("\n" + "="*80)
        print("Step 4: Calculating Consumption Uncertainty")
        print("="*80)

        # Create consumption results storage
        consumption_dfs = []

        # For each year, calculate consumption for each region and parameter combination
        for year_idx, year in enumerate(YEARS_TO_PROCESS, 1):
            print(f"\n  Processing year {year} ({year_idx}/{len(YEARS_TO_PROCESS)})...")

            # Load population raster for this year
            pop_data, pop_profile = load_population_raster(year)
            if pop_data is None:
                print(f"    Skipping year {year} - population raster not found")
                continue

            # Load urban raster for this year
            urban_data = None
            if os.path.exists(URBAN_RURAL_BASE_PATH):
                urban_data = load_urban_raster(year, pop_profile)
                if urban_data is None:
                    print(f"    Using default urban values for {year}")
                    urban_data = np.full(pop_data.shape, 20.0, dtype=np.float32)

            # Process each region
            for region in SAUDI_REGIONS:
                print(f"    Processing {region}...")

                # Load region mask
                region_mask = load_region_mask(region, pop_profile)
                if region_mask is None:
                    print(f"      Skipping {region} - mask not found")
                    continue

                # Get NRW value for this region and year
                nrw_row = df[(df['Region'] == region) & (df['Year'] == year)]
                nrw_value = nrw_row['NRW'].iloc[0] if not nrw_row.empty else NRW_DEFAULT

                # Process each parameter combination
                region_consumption_data = {'Region': region, 'Year': year}

                for pred_col in ['P_1', 'P_2', 'P_3']:
                    if pred_col in out_df.columns:
                        # Get LCD prediction for this region and year
                        lcd_row = out_df[(out_df['Region'] == region) & (out_df['Year'] == year)]
                        lcd_pred = lcd_row[pred_col].iloc[0] if not lcd_row.empty else np.nan

                        if pd.notna(lcd_pred):
                            # Prepare arguments for parallel processing
                            args = (year, region, lcd_pred, nrw_value, pop_data,
                                   pop_profile, urban_data, region_mask)

                            # Calculate consumption
                            result = calculate_consumption_for_combination(args)

                            if result['success']:
                                # Add to results
                                region_consumption_data[f'{pred_col}_Withdrawal_m3'] = result['total_withdrawal']
                                region_consumption_data[f'{pred_col}_Consumption_m3'] = result['total_consumption']
                                region_consumption_data[f'{pred_col}_Consumption_LCD'] = (
                                    result['total_consumption'] / np.sum(pop_data[region_mask]) * 1000 / 365
                                    if np.sum(pop_data[region_mask]) > 0 else np.nan
                                )

                # Also calculate for normalized predictions
                for pred_col in ['P_1', 'P_2', 'P_3']:
                    for pop_idx in [1, 2, 3]:
                        norm_col = f"{pred_col}R{pop_idx}"
                        if norm_col in out_df.columns:
                            lcd_row = out_df[(out_df['Region'] == region) & (out_df['Year'] == year)]
                            lcd_pred = lcd_row[norm_col].iloc[0] if not lcd_row.empty else np.nan

                            if pd.notna(lcd_pred):
                                args = (year, region, lcd_pred, nrw_value, pop_data,
                                       pop_profile, urban_data, region_mask)

                                result = calculate_consumption_for_combination(args)

                                if result['success']:
                                    region_consumption_data[f'{norm_col}_Withdrawal_m3'] = result['total_withdrawal']
                                    region_consumption_data[f'{norm_col}_Consumption_m3'] = result['total_consumption']
                                    region_consumption_data[f'{norm_col}_Consumption_LCD'] = (
                                        result['total_consumption'] / np.sum(pop_data[region_mask]) * 1000 / 365
                                        if np.sum(pop_data[region_mask]) > 0 else np.nan
                                    )

                consumption_dfs.append(pd.DataFrame([region_consumption_data]))

        # Combine all consumption results
        if consumption_dfs:
            consumption_df = pd.concat(consumption_dfs, ignore_index=True)

            # Merge with main output
            out_df = pd.merge(out_df, consumption_df, on=['Region', 'Year'], how='left')

            print(f"\n  Added consumption calculations for {len(consumption_df)} region-year combinations")
        else:
            print("\n  No consumption calculations were performed")

    # FINAL CLEANUP AND OUTPUT
    print("\nStep 5: Finalizing output...")

    # Clean up temporary columns
    temp_cols = [col for col in out_df.columns if '_temp' in col]
    if temp_cols:
        out_df = out_df.drop(columns=temp_cols)

    # Remove any duplicate columns
    out_df = out_df.loc[:, ~out_df.columns.duplicated()]

    # Reorder columns for better readability
    base_cols = ['Region', 'Year', 'LiterCapitaDay', 'NRW']
    lcd_cols = [c for c in out_df.columns if c.startswith('LCD_')]
    p_cols = [c for c in out_df.columns if c.startswith('P_') and 'R' not in c and 'Withdrawal' not in c and 'Consumption' not in c]
    pr_cols = [c for c in out_df.columns if 'R' in c and c.startswith('P_') and 'Withdrawal' not in c and 'Consumption' not in c]

    # Consumption columns (if calculated)
    withdrawal_cols = [c for c in out_df.columns if 'Withdrawal' in c]
    consumption_cols = [c for c in out_df.columns if 'Consumption' in c and 'LCD' not in c]
    consumption_lcd_cols = [c for c in out_df.columns if 'Consumption_LCD' in c]

    # Create final column order
    final_cols = (base_cols + lcd_cols + p_cols + pr_cols +
                 withdrawal_cols + consumption_cols + consumption_lcd_cols)
    existing_cols = [c for c in final_cols if c in out_df.columns]

    # Add any remaining columns
    remaining_cols = [c for c in out_df.columns if c not in existing_cols]
    final_cols_order = existing_cols + remaining_cols

    out_df = out_df[final_cols_order]

    # Save outputs
    output_path = f"{OUTPUT_DIR}/LCD_Predictions_With_withdrawal_Uncertainty.xlsx"
    out_df.to_excel(output_path, index=False)

    # Also save a summary file
    summary_cols = ['Region', 'Year', 'LiterCapitaDay', 'NRW']
    for pred in ['P_1', 'P_2', 'P_3']:
        if pred in out_df.columns:
            summary_cols.append(pred)
        for pop_idx in [1, 2, 3]:
            norm_col = f"{pred}R{pop_idx}"
            if norm_col in out_df.columns:
                summary_cols.append(norm_col)
                if f"{norm_col}_Consumption_m3" in out_df.columns:
                    summary_cols.append(f"{norm_col}_Consumption_m3")

    summary_df = out_df[summary_cols]
    summary_path = f"{OUTPUT_DIR}/withdrawal_Uncertainty_Summary.xlsx"
    summary_df.to_excel(summary_path, index=False)

    print("\n" + "="*80)
    print("PROCESSING COMPLETE!")
    print("="*80)
    print(f"Main output saved to: {output_path}")
    print(f"Summary saved to: {summary_path}")
    print(f"\nTotal columns in output: {len(out_df.columns)}")
    print(f"Total rows: {len(out_df)}")

    # Show statistics
    if CALCULATE_CONSUMPTION:
        print("\nCONSUMPTION UNCERTAINTY STATISTICS:")
        print("-" * 40)

        consumption_cols = [c for c in out_df.columns if 'Consumption_m3' in c]
        if consumption_cols:
            for col in consumption_cols:
                non_null = out_df[col].notna().sum()
                if non_null > 0:
                    mean_val = out_df[col].mean()
                    std_val = out_df[col].std()
                    print(f"{col}:")
                    print(f"  Non-null values: {non_null}")
                    print(f"  Mean: {mean_val:,.0f} m³/year")
                    print(f"  Std Dev: {std_val:,.0f} m³/year")
                    print(f"  CV: {(std_val/mean_val*100 if mean_val!=0 else np.nan):.1f}%")
                    print()

if __name__ == "__main__":
    main()
