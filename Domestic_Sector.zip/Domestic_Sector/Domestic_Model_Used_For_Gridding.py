import os
import numpy as np
import pandas as pd
import math
import warnings
import rasterio
import time
from datetime import datetime
from rasterio.warp import reproject, Resampling
from concurrent.futures import ProcessPoolExecutor, as_completed
from multiprocessing import cpu_count
import traceback

warnings.filterwarnings("ignore")

# CONFIGURATION
CALCULATION_TYPE = 'withdrawal'
DEBUG_LEVEL = 'normal'  # 'minimal', 'normal', 'detailed', 'verbose'
PARALLEL_PROCESSING = True  # Enable parallel processing
MAX_WORKERS = cpu_count() - 4  # Leave 2 cores free

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
URBAN_RURAL_BASE_PATH = os.path.join(BASE_DIR, "Spatial_Data", "GHSL_urban_rural_3arcsec")
URBAN_VALUE_MAX = 30
URBAN_VALUE_MIN = 10

INPUT_PATH = os.path.join(BASE_DIR, "Domestic_Data_Set.xlsx")
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")

Pop_National_BASE_PATH = os.path.join(BASE_DIR, "Spatial_Data", "Population_Rasters")
REGION_MASKS_PATH = os.path.join(BASE_DIR, "Spatial_Data", "Region_Masks")

os.makedirs(OUTPUT_DIR, exist_ok=True)
if CALCULATION_TYPE == 'consumption':
    WATER_RASTER_EXPORT_PATH = os.path.join(OUTPUT_DIR, "water_consumption_rasters")
else:
    WATER_RASTER_EXPORT_PATH = os.path.join(OUTPUT_DIR, "water_withdrawal_rasters")
os.makedirs(WATER_RASTER_EXPORT_PATH, exist_ok=True)

PRELIMINARY_EXPORT_PATH = os.path.join(OUTPUT_DIR, "predicted_lcd_before_gridding.xlsx")
DETAILED_EXPORT_PATH = os.path.join(OUTPUT_DIR, f"detailed_water_{CALCULATION_TYPE}_results.xlsx")

YEARS_TO_PROCESS = [1999,2001,2021,2022]

SAUDI_REGIONS = ['Riyadh','Makkah','Madinah','Eastern Province','Qasim','Asir','Tabuk',
                 'Hael','Jazan','Najran','Baha','Jouf','Northern Boarders']
# HELPER FUNCTIONS

def debug_print(level, message):
    """Conditional debug printing"""
    debug_levels = {'minimal': 1, 'normal': 2, 'detailed': 3, 'verbose': 4}
    current_level = debug_levels.get(DEBUG_LEVEL, 2)
    message_level = debug_levels.get(level, 2)

    if message_level <= current_level:
        print(f"[{level.upper()}] {message}")

def gdp_sigmoid(inf_gdp):
    return 50 + 450 / (1 + np.exp(-2.06550308 * ((inf_gdp / 100000) - 0.65103896)))

def safe_div(a, b, fill=np.nan):
    try:
        a = np.asarray(a, dtype=float)
        b = np.asarray(b, dtype=float)
        out = np.divide(a, b, out=np.full_like(a, fill, dtype=float), where=(b!=0))
        if out.size == 1:
            return float(out)
        return out
    except Exception:
        return fill

def get_urban_rural_constant(urban_value):
    """Calculate constant based on urban/rural cell value"""
    if np.isnan(urban_value):
        return 0.5  # Default to rural for NaN

    # Clamp values to [10, 30] range as requested
    clamped_value = np.clip(urban_value, URBAN_VALUE_MIN, URBAN_VALUE_MAX)

    # Linear interpolation between (10, 0.5) and (30, 0.1)
    return 0.5 + (clamped_value - URBAN_VALUE_MIN) * (0.1 - 0.5) / (URBAN_VALUE_MAX - URBAN_VALUE_MIN)

# Vectorized version for efficiency
get_urban_rural_constant_vectorized = np.vectorize(get_urban_rural_constant)

def load_and_resample_raster(source_path, target_profile, name="raster"):
    """Load and resample any raster to match target profile"""
    if not os.path.exists(source_path):
        debug_print('normal', f"File not found: {source_path}")
        return None

    try:
        with rasterio.open(source_path) as src:
            # Read data
            data = src.read(1).astype(np.float32)

            # Create output array
            resampled = np.zeros((target_profile['height'], target_profile['width']), dtype=np.float32)

            # Handle NaN values in source
            data_nodata = data.copy()
            if src.nodata is not None:
                data_nodata[data == src.nodata] = np.nan

            # Reproject to target grid
            reproject(
                source=data_nodata,
                destination=resampled,
                src_transform=src.transform,
                src_crs=src.crs,
                dst_transform=target_profile['transform'],
                dst_crs=target_profile['crs'],
                resampling=Resampling.bilinear  # Use bilinear for continuous data
            )

            debug_print('detailed', f"{name} resampled: {data.shape} -> {resampled.shape}")
            return resampled

    except Exception as e:
        debug_print('normal', f"Error loading {name}: {e}")
        return None

def process_year_region(args):
    """Process a single region for a single year (for parallel processing)"""
    year, region_data, pop_data, pop_transform, pop_crs, pop_profile = args

    region_name = region_data['Region']
    results = {}

    try:
        # Load region mask
        mask_path = os.path.join(REGION_MASKS_PATH, f"{region_name}.tif")
        mask = load_and_resample_raster(mask_path, pop_profile, f"Mask_{region_name}")

        if mask is None:
            debug_print('normal', f"Skipping {region_name} - mask not found")
            return results

        # Apply mask to get region extent
        region_mask = mask > 0
        if not np.any(region_mask):
            debug_print('normal', f"Skipping {region_name} - no valid mask cells")
            return results

        # Load urban data if needed
        urban_data = None
        if CALCULATION_TYPE == 'consumption':
            urban_path = os.path.join(URBAN_RURAL_BASE_PATH, f"urban_{year}.tif")
            urban_data = load_and_resample_raster(urban_path, pop_profile, f"Urban_{year}")

            # If urban data not found, use default (20 = midpoint)
            if urban_data is None:
                urban_data = np.full(pop_data.shape, 20.0, dtype=np.float32)
                debug_print('normal', f"Using default urban value 20 for {region_name}")

        # Extract region data
        region_pop = np.where(region_mask, pop_data, 0)
        region_pop_valid = region_pop[region_mask]

        # Skip if no Pop_National in region
        if np.sum(region_pop_valid) == 0:
            debug_print('normal', f"Skipping {region_name} - no Pop_National in mask area")
            return results

        # Calculate water demand
        if CALCULATION_TYPE == 'withdrawal':
            # Withdrawal calculation
            water_raster = region_data['LCD_Prediction'] * region_pop * 365 / 1000
        else:
            # Consumption calculation (NEW EQUATION)
            withdrawal_raster = region_data['LCD_Prediction'] * region_pop * 365 / 1000
            nrw_fraction = region_data['NRW'] / 100  # NRW as fraction (0-1)

            # Calculate consumption using new equation:
            # consumption = withdrawal × NRW% + withdrawal × (1 - NRW%) × Urban_Rural_Constant

            # First term: NRW portion (fully consumed by system)
            nrw_portion = withdrawal_raster * nrw_fraction

            # Second term: Delivered portion multiplied by urban/rural constant
            if urban_data is not None:
                # Extract urban data for region
                region_urban = urban_data[region_mask]
                # Calculate constants for region only (more efficient)
                urban_constants = get_urban_rural_constant_vectorized(region_urban)

                # Create full raster for urban constants
                urban_constant_raster = np.zeros_like(withdrawal_raster, dtype=np.float32)
                urban_constant_raster[region_mask] = urban_constants

                # Calculate delivered portion with urban constant
                delivered_portion = withdrawal_raster * (1 - nrw_fraction) * urban_constant_raster
            else:
                # If no urban data, use default constant (0.3 = midpoint)
                urban_constant_raster = np.full_like(withdrawal_raster, 0.3, dtype=np.float32)
                delivered_portion = withdrawal_raster * (1 - nrw_fraction) * urban_constant_raster

            # Total consumption = NRW portion + delivered portion
            water_raster = nrw_portion + delivered_portion

        # Set non-region areas to 0
        water_raster = np.where(region_mask, water_raster, 0)

        # Calculate statistics
        valid_water = water_raster[region_mask]
        total_water = np.sum(valid_water)

        # Prepare results
        results = {
            'region_name': region_name,
            'year': year,
            'water_raster': water_raster.astype(np.float32),
            'total_water': total_water,
            'pop_in_region': np.sum(region_pop_valid),
            'cells_in_region': np.sum(region_mask),
            'success': True
        }

        debug_print('normal', f"Completed {region_name} {year}: {total_water:,.0f} m³")

    except Exception as e:
        debug_print('normal', f"Error processing {region_name} {year}: {str(e)}")
        results = {
            'region_name': region_name,
            'year': year,
            'success': False,
            'error': str(e)
        }

    return results

# MAIN PROCESSING

def main():
    start_time = time.time()
    print(f"{'='*70}")
    print(f"WATER DEMAND MODEL - {CALCULATION_TYPE.upper()} CALCULATION")
    print(f"{'='*70}")
    print(f"Start time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Parallel processing: {PARALLEL_PROCESSING}")
    if PARALLEL_PROCESSING:
        print(f"Max workers: {MAX_WORKERS}")
    print(f"{'='*70}\n")

    # STEP 1: Load and process Excel data
    print(f"STEP 1: Loading Excel data...")
    try:
        df = pd.read_excel(INPUT_PATH)
        df.columns = df.columns.str.strip()

        # Check required columns
        required = ['Year', 'Region', 'Relation', 'HouseholdSize', 'LiterCapitaDay',
                   'GDP_per_capita_stat', 'Pipe', 'Pop_National_Statistics', 'NRW']


        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")

        # Clean data
        df['Year'] = df['Year'].astype(str).str.extract(r'(\d{4})')[0].astype(int)
        df['Region'] = df['Region'].astype(str).str.strip()
        df['Relation'] = df['Relation'].astype(str).str.strip()
        df.loc[df['Relation'].str.lower().isin(['no', 'none', '-', 'nan', '']), 'Relation'] = 'No'

        # Handle NRW
        df['NRW'] = pd.to_numeric(df['NRW'], errors='coerce').fillna(30)

        print(f"Excel loaded: {len(df)} rows, {df['Year'].nunique()} years, {df['Region'].nunique()} regions")

    except Exception as e:
        print(f"Error loading Excel: {e}")
        traceback.print_exc()
        return

    # STEP 2: Calculate LCD predictions using PLR method (from second code)
    print(f"\nSTEP 2: Calculating LCD predictions using PLR method...")

    # Filter to years we need
    df = df[df['Year'].isin(YEARS_TO_PROCESS)].copy()

    # PLR calculation
    countries = df[df['Relation']=='No']['Region'].unique().tolist()

    def compute_country_series(country_df):
        country_df = country_df.sort_values('Year').copy()
        country_df['LCD_Prediction'] = np.nan
        base_year = 2020 if 2020 in country_df['Year'].values else country_df['Year'].max()
        base_row = country_df[country_df['Year']==base_year].iloc[0]
        lcd_base = base_row['LiterCapitaDay']
        if pd.isna(lcd_base):
            if pd.notna(base_row['GDP_per_capita_stat']):
                lcd_base = gdp_sigmoid(base_row['GDP_per_capita_stat'])
            else:
                lcd_base = country_df['LiterCapitaDay'].median()
        for idx, row in country_df.iterrows():
            hh_ratio = safe_div(base_row['HouseholdSize'], row['HouseholdSize'])
            gdp_ratio = safe_div(row['GDP_per_capita_stat'], base_row['GDP_per_capita_stat'])
            pipe_ratio = safe_div(row['Pipe'], base_row['Pipe'])

            ###############################################################################################################
            pred = lcd_base * (((hh_ratio**0.5)*(gdp_ratio**0.5)))
            ###############################################################################################################
            country_df.at[idx, 'LCD_Prediction'] = pred
            debug_print('detailed', f"Debug: {row['Region']} {row['Year']} LCD prediction={pred:.2f}")
        return country_df

    country_dfs = [compute_country_series(df[(df['Region']==c)&(df['Relation']=='No')]) for c in countries]
    df_countries = pd.concat(country_dfs, ignore_index=True)

    # Regions (Relation != 'No')
    regions_df = df[df['Relation']!='No'].copy()
    country_lookup = df_countries.set_index(['Region','Year'])['LCD_Prediction'].to_dict()

    regions_out = []
    for idx,row in regions_df.iterrows():
        parent_lcd = country_lookup.get((row['Relation'], row['Year']), np.nan)
        pred = np.nan
        if pd.notna(parent_lcd):
            hh_ratio = safe_div(df_countries.loc[(df_countries['Region']==row['Relation']) & (df_countries['Year']==row['Year']), 'HouseholdSize'].values[0],
                                row['HouseholdSize'])
            pipe_ratio = row['Pipe'] / df_countries.loc[(df_countries['Region']==row['Relation']) & (df_countries['Year']==row['Year']), 'Pipe'].values[0]

            ######################################################################################################################
            pred = parent_lcd * (hh_ratio**0.5) * (pipe_ratio**0.5)
            ######################################################################################################################

        out_row = row.to_dict()
        out_row['LCD_Prediction'] = pred
        regions_out.append(out_row)
        debug_print('detailed', f"Debug: {row['Region']} {row['Year']} Region LCD={pred:.2f}")

    df_regions = pd.DataFrame(regions_out)
    df_predicted_lcd = pd.concat([df_countries, df_regions], ignore_index=True)

    # STEP 2a: Apply Saudi normalization
    print(f"\nSTEP 2a: Applying Saudi normalization...")

    # Calculate water totals
    df_predicted_lcd['Water_m3'] = df_predicted_lcd['LCD_Prediction'] * df_predicted_lcd['Pop_National_Statistics'] * 365 / 1000

    # Normalize Saudi regions (from second code)
    saudi_total_regions_water = df_predicted_lcd[df_predicted_lcd['Region'].isin(SAUDI_REGIONS)]['Water_m3'].sum()
    saudi_total_country_row = df_predicted_lcd[(df_predicted_lcd['Region']=='Saudi')]
    if not saudi_total_country_row.empty:
        lcd_country = saudi_total_country_row['LCD_Prediction'].values[0]
        pop_country = df_predicted_lcd[df_predicted_lcd['Region'].isin(SAUDI_REGIONS)]['Pop_National_Statistics'].sum()
        saudi_total_country_water = lcd_country * pop_country * 365 / 1000
        norm_factor = safe_div(saudi_total_country_water, saudi_total_regions_water, 1.0)
        print(f"Saudi normalization factor: {norm_factor:.4f}")
        # Apply normalization
        df_predicted_lcd.loc[df_predicted_lcd['Region'].isin(SAUDI_REGIONS), 'Water_m3'] *= norm_factor
        df_predicted_lcd.loc[df_predicted_lcd['Region'].isin(SAUDI_REGIONS), 'LCD_Prediction'] = \
            df_predicted_lcd.loc[df_predicted_lcd['Region'].isin(SAUDI_REGIONS), 'Water_m3'] / \
            df_predicted_lcd.loc[df_predicted_lcd['Region'].isin(SAUDI_REGIONS), 'Pop_National_Statistics'] * 1000 / 365

    # Save debug Excel before gridding
    df_predicted_lcd.to_excel(PRELIMINARY_EXPORT_PATH, index=False)
    print(f"Predicted LCD (post-normalization) saved: {PRELIMINARY_EXPORT_PATH}")

    # Save detailed results with water calculations
    if CALCULATION_TYPE == 'withdrawal':
        df_predicted_lcd['Withdrawal_m3'] = df_predicted_lcd['LCD_Prediction'] * df_predicted_lcd['Pop_National_Statistics'] * 365 / 1000
    else:
        # New consumption calculation for Excel summary
        withdrawal = df_predicted_lcd['LCD_Prediction'] * df_predicted_lcd['Pop_National_Statistics'] * 365 / 1000
        nrw_fraction = df_predicted_lcd['NRW'] / 100

        # For Excel, we need to estimate urban/rural constant
        # Using average value (0.3) for simplicity in Excel summary
        avg_urban_constant = 0.3
        df_predicted_lcd['Withdrawal_m3'] = withdrawal
        df_predicted_lcd['Consumption_m3'] = (withdrawal * nrw_fraction) + (withdrawal * (1 - nrw_fraction) * avg_urban_constant)

    df_predicted_lcd.to_excel(DETAILED_EXPORT_PATH, index=False)
    print(f"Detailed water demand results saved: {DETAILED_EXPORT_PATH}")

    # STEP 3: Replace df with df_predicted_lcd for raster processing
    print(f"\nSTEP 3: Preparing for raster processing with PLR-calculated LCD...")

    # IMPORTANT: Replace df with df_predicted_lcd for the rest of the processing
    df = df_predicted_lcd.copy()

    # STEP 4: Process each year (original Step 3 from first code)
    print(f"\nSTEP 4: Processing raster data...")
    print(f"Years to process: {YEARS_TO_PROCESS}")

    for year_idx, year in enumerate(YEARS_TO_PROCESS, 1):
        year_start = time.time()
        print(f"\n{'='*60}")
        print(f"PROCESSING YEAR {year} ({year_idx}/{len(YEARS_TO_PROCESS)})")
        print(f"{'='*60}")

        # Load Pop_National raster for this year
        pop_path = os.path.join(Pop_National_BASE_PATH, f"pop{year}_raster.tif")
        if not os.path.exists(pop_path):
            print(f"Pop_National raster not found for {year}: {pop_path}")
            continue

        try:
            with rasterio.open(pop_path) as src:
                pop_data = src.read(1).astype(np.float32)
                pop_transform = src.transform
                pop_crs = src.crs
                pop_profile = src.profile

            # Replace NaN with 0 in Pop_National data
            pop_data = np.where(np.isnan(pop_data), 0, pop_data)

            print(f"Pop_National raster loaded: {pop_data.shape}")
            print(f"   Total Pop_National: {pop_data.sum():,.0f}")
            print(f"   Non-zero cells: {np.sum(pop_data > 0):,}")

        except Exception as e:
            print(f"Error loading Pop_National raster for {year}: {e}")
            continue

        # Get regions for this year
        year_data = df[df['Year'] == year]
        if year_data.empty:
            print(f"No data for year {year}")
            continue

        print(f"Processing {len(year_data)} regions for {year}")

        # Prepare arguments for parallel processing
        process_args = []
        for _, region_row in year_data.iterrows():
            args = (year, region_row.to_dict(), pop_data, pop_transform, pop_crs, pop_profile)
            process_args.append(args)

        # Process regions
        successful_regions = 0
        total_water_year = 0

        if PARALLEL_PROCESSING and len(process_args) > 1:
            # Parallel processing
            print(f"Starting parallel processing with {min(MAX_WORKERS, len(process_args))} workers...")

            with ProcessPoolExecutor(max_workers=min(MAX_WORKERS, len(process_args))) as executor:
                futures = {executor.submit(process_year_region, args): args for args in process_args}

                for future in as_completed(futures):
                    try:
                        result = future.result()

                        if result.get('success', False):
                            # Save raster
                            region_name = result['region_name']
                            water_raster = result['water_raster']

                            out_path = os.path.join(WATER_RASTER_EXPORT_PATH,
                                                   f"water_{CALCULATION_TYPE}_{region_name}_{year}.tif")

                            # Save raster
                            profile = {
                                'driver': 'GTiff',
                                'height': water_raster.shape[0],
                                'width': water_raster.shape[1],
                                'count': 1,
                                'dtype': water_raster.dtype,
                                'crs': pop_crs,
                                'transform': pop_transform,
                                'nodata': 0,
                                'compress': 'lzw'
                            }

                            with rasterio.open(out_path, 'w', **profile) as dst:
                                dst.write(water_raster, 1)

                            total_water_year += result['total_water']
                            successful_regions += 1

                            print(f"  {region_name}: {result['total_water']:,.0f} m³, "
                                  f"pop: {result['pop_in_region']:,.0f}, "
                                  f"cells: {result['cells_in_region']:,}")

                        else:
                            region_name = result.get('region_name', 'Unknown')
                            print(f"  {region_name}: Failed - {result.get('error', 'Unknown error')}")

                    except Exception as e:
                        print(f"  Error in parallel processing: {e}")
        else:
            # Sequential processing
            print(f"Processing sequentially...")
            for args in process_args:
                result = process_year_region(args)

                if result.get('success', False):
                    # Save raster
                    region_name = result['region_name']
                    water_raster = result['water_raster']

                    out_path = os.path.join(WATER_RASTER_EXPORT_PATH,
                                           f"water_{CALCULATION_TYPE}_{region_name}_{year}.tif")

                    # Save raster
                    profile = {
                        'driver': 'GTiff',
                        'height': water_raster.shape[0],
                        'width': water_raster.shape[1],
                        'count': 1,
                        'dtype': water_raster.dtype,
                        'crs': pop_crs,
                        'transform': pop_transform,
                        'nodata': 0,
                        'compress': 'lzw'
                    }

                    with rasterio.open(out_path, 'w', **profile) as dst:
                        dst.write(water_raster, 1)

                    total_water_year += result['total_water']
                    successful_regions += 1

                    print(f"  {region_name}: {result['total_water']:,.0f} m³, "
                          f"pop: {result['pop_in_region']:,.0f}, "
                          f"cells: {result['cells_in_region']:,}")

                else:
                    region_name = result.get('region_name', 'Unknown')
                    print(f"  {region_name}: Failed - {result.get('error', 'Unknown error')}")

        # Year summary
        year_time = time.time() - year_start
        print(f"\nYEAR {year} SUMMARY:")
        print(f"   Successful regions: {successful_regions}/{len(year_data)}")
        print(f"   Total {CALCULATION_TYPE}: {total_water_year:,.0f} m³")
        print(f"   Processing time: {year_time:.1f}s")

    # Final summary
    total_time = time.time() - start_time
    print(f"\n{'='*70}")
    print(f"PROCESSING COMPLETED!")
    print(f"{'='*70}")
    print(f"Total processing time: {total_time:.1f}s ({total_time/60:.1f} minutes)")
    print(f"Output directory: {WATER_RASTER_EXPORT_PATH}")
    print(f"Preliminary LCD results: {PRELIMINARY_EXPORT_PATH}")
    print(f"Detailed results: {DETAILED_EXPORT_PATH}")
    print(f"{'='*70}")

if __name__ == "__main__":
    main()
