import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import os
from matplotlib.patches import Patch

# Set up input and output paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_PATH = os.path.join(BASE_DIR, "Output", "LCD_Predictions_With_withdrawal_Uncertainty.xlsx")
OUTPUT_DIR = os.path.join(BASE_DIR, "Output")

# Create output directory if it doesn't exist
os.makedirs(OUTPUT_DIR, exist_ok=True)
print(f"Output directory: {OUTPUT_DIR}")

def plot_pred_vs_obs(data, title, filename, xlim=None, ylim=None):
    """
    Plot predicted vs observed values with error bars.
    """
    fig, ax = plt.subplots(figsize=(7, 6))

    # Define colors for different regions
    unique_regions = sorted(data["Region"].unique())
    colors = plt.cm.tab20(np.linspace(0, 1, len(unique_regions)))
    region_colors = dict(zip(unique_regions, colors))

    for region in unique_regions:
        sub = data[data["Region"] == region]

        ax.errorbar(
            sub["Observed_mean"],
            sub["Predicted_mean"],
            xerr=sub["Observed_std"],
            yerr=sub["Predicted_std"],
            fmt="o",
            markersize=4,
            color=region_colors[region],
            alpha=0.8,
            label=region
        )

    # 1:1 dashed line
    ax.plot([0, 500], [0, 500], linestyle="--", color="gray", linewidth=1)

    ax.set_xlabel("Reported Water Withdrawal (L/cap/d)")
    ax.set_ylabel("Reconstructed Water Withdrawal (L/cap/d)")

    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)

    # Legend inside the plot at top-left
    ax.legend(fontsize=10, loc='upper left', facecolor='white', framealpha=1)
    #ax.grid(True, linestyle="--", alpha=0.4)

    outpath = os.path.join(OUTPUT_DIR, filename)
    plt.tight_layout()
    plt.savefig(outpath, dpi=300)
    plt.close()
    print(f"[SAVED] {outpath}")

def plot_pred_vs_obs_new(data, title, filename, xlim=None, ylim=None):
    """
    Plot predicted vs observed values with error bars.
    """
    fig, ax = plt.subplots(figsize=(7, 6))

    unique_regions = sorted(data["Region"].unique())
    colors = plt.cm.tab20(np.linspace(0, 1, len(unique_regions)))
    region_colors = dict(zip(unique_regions, colors))

    for region in unique_regions:
        sub = data[data["Region"] == region]

        ax.errorbar(
            sub["Observed_mean"],
            sub["Predicted_mean"],
            xerr=sub["Observed_std"],
            yerr=sub["Predicted_std"],
            fmt="o",
            markersize=4,
            color=region_colors[region],
            alpha=0.8,
            label=region
        )

    # 1:1 line
    ax.plot([0, 500], [0, 500], linestyle="--", color="gray", linewidth=1)

    ax.set_xlabel("Reported Water Withdrawal (L/cap/d)")
    ax.set_ylabel("Reconstructed Water Withdrawal (L/cap/d)")

    if xlim:
        ax.set_xlim(xlim)
    if ylim:
        ax.set_ylim(ylim)

    # legend reordering for 2 columns
    handles, labels = ax.get_legend_handles_labels()

    n = len(labels)
    mid = (n + 1) // 2

    # split into two halves and interleave for column-wise balance
    new_order = []
    for i in range(mid):
        new_order.append(i)
        if i + mid < n:
            new_order.append(i + mid)

    handles = [handles[i] for i in new_order]
    labels = [labels[i] for i in new_order]

    ax.legend(
        handles,
        labels,
        title="Sub-National Level",
        fontsize=10,
        loc="lower right",
        ncol=2,
        framealpha=1,
        facecolor="white"
    )

    outpath = os.path.join(OUTPUT_DIR, filename)
    plt.tight_layout()
    plt.savefig(outpath, dpi=300)
    plt.close()
    print(f"[SAVED] {outpath}")


def create_country_subplots(df_no):
    """
    Create 3x3 subplots for countries (Relation='no')
    Each subplot shows one country with:
    - LCD_1, LCD_2, LCD_3 combined as single points (median ± std) per year
    - P_1, P_2, P_3 as min-max shadow with median line (withdrawal)
    - C_1, C_2, C_3 as min-max shadow with median line (consumption)
    """
    if df_no.empty:
        print("No data for countries (Relation='no')")
        return

    # Get unique countries
    unique_regions = sorted(df_no["Region"].unique())

    # Calculate grid size: we need at most 9 subplots (3x3)
    if len(unique_regions) > 9:
        print(f"Warning: Too many countries ({len(unique_regions)}). Showing first 9.")
        unique_regions = unique_regions[:9]

    # Create 3x3 grid
    n_rows, n_cols = 2, 4
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(22, 10), sharex=False, sharey=False)

    # Flatten axes array for easy indexing
    if n_rows * n_cols > 1:
        axes_flat = axes.flatten()
    else:
        axes_flat = [axes]

    # Create a color map for regions
    region_colors = plt.cm.tab20(np.linspace(0, 1, len(unique_regions)))
    color_dict = dict(zip(unique_regions, region_colors))

    for idx, region in enumerate(unique_regions):
        if idx >= len(axes_flat):
            break

        ax = axes_flat[idx]
        region_data = df_no[df_no['Region'] == region].sort_values('Year')

        if region_data.empty:
            ax.text(0.5, 0.5, f"No data\nfor {region}",
                   ha='center', va='center', transform=ax.transAxes)
            ax.set_title(region, fontsize=12, fontweight='bold')
            continue

        # Prepare data for plotting
        years = sorted(region_data['Year'].unique())
        lcd_medians = []
        lcd_stds = []

        # Withdrawal data (P columns)
        p_mins = []
        p_maxs = []
        p_medians = []

        # Consumption data (C columns)
        c_mins = []
        c_maxs = []
        c_medians = []

        for year in years:
            year_data = region_data[region_data['Year'] == year]

            # Check if we have complete P data (P_1, P_2, P_3) for withdrawal
            has_complete_p = True
            for col in ['P_1', 'P_2', 'P_3']:
                if col not in year_data.columns or pd.isna(year_data[col].iloc[0]) or year_data[col].iloc[0] == 0:
                    has_complete_p = False
                    break

            # Check if we have complete C data (C_1, C_2, C_3) for consumption
            has_complete_c = True
            for col in ['C_1', 'C_2', 'C_3']:
                if col not in year_data.columns or pd.isna(year_data[col].iloc[0]) or year_data[col].iloc[0] == 0:
                    has_complete_c = False
                    break

            # Skip year if we don't have complete P data (withdrawal is required)
            if not has_complete_p:
                continue

            # Get LCD values (LCD_1, LCD_2, LCD_3) - accept whatever is available
            lcd_values = []
            for col in ['LCD_1', 'LCD_2', 'LCD_3']:
                if col in year_data.columns:
                    value = year_data[col].iloc[0]
                    if pd.notna(value) and value != 0:
                        lcd_values.append(value)

            # Get P values (P_1, P_2, P_3) for withdrawal - we know they're all available
            p_values = []
            for col in ['P_1', 'P_2', 'P_3']:
                value = year_data[col].iloc[0]
                p_values.append(value)

            # Get C values (C_1, C_2, C_3) for consumption if available
            c_values = []
            if has_complete_c:
                for col in ['C_1', 'C_2', 'C_3']:
                    value = year_data[col].iloc[0]
                    c_values.append(value)

            # Always add LCD data if we have complete P data
            if lcd_values:
                lcd_medians.append(np.median(lcd_values))
                lcd_stds.append(np.std(lcd_values) if len(lcd_values) > 1 else 0)
            else:
                # If no LCD data, still show P data
                lcd_medians.append(np.nan)
                lcd_stds.append(np.nan)

            # Add P data (withdrawal) - always available since we checked
            p_mins.append(np.min(p_values))
            p_maxs.append(np.max(p_values))
            p_medians.append(np.median(p_values))

            # Add C data (consumption) if available
            if has_complete_c and c_values:
                c_mins.append(np.min(c_values))
                c_maxs.append(np.max(c_values))
                c_medians.append(np.median(c_values))
            else:
                c_mins.append(np.nan)
                c_maxs.append(np.nan)
                c_medians.append(np.nan)

        # Convert to numpy arrays
        years_filtered = []
        lcd_medians_filtered = []
        lcd_stds_filtered = []
        p_mins_filtered = []
        p_maxs_filtered = []
        p_medians_filtered = []
        c_mins_filtered = []
        c_maxs_filtered = []
        c_medians_filtered = []

        for i, year in enumerate(years):
            # Only include years where we have P data
            if i < len(p_mins):  # This means we have P data for this year
                years_filtered.append(year)
                lcd_medians_filtered.append(lcd_medians[i] if i < len(lcd_medians) else np.nan)
                lcd_stds_filtered.append(lcd_stds[i] if i < len(lcd_stds) else np.nan)
                p_mins_filtered.append(p_mins[i])
                p_maxs_filtered.append(p_maxs[i])
                p_medians_filtered.append(p_medians[i])
                c_mins_filtered.append(c_mins[i] if i < len(c_mins) else np.nan)
                c_maxs_filtered.append(c_maxs[i] if i < len(c_maxs) else np.nan)
                c_medians_filtered.append(c_medians[i] if i < len(c_medians) else np.nan)

        if not years_filtered:
            ax.text(0.5, 0.5, f"No complete P data\nfor {region}",
                   ha='center', va='center', transform=ax.transAxes)
            ax.set_title(region, fontsize=12, fontweight='bold')
            continue

        # Convert to numpy arrays
        years_array = np.array(years_filtered)
        lcd_medians_array = np.array(lcd_medians_filtered)
        lcd_stds_array = np.array(lcd_stds_filtered)
        p_mins_array = np.array(p_mins_filtered)
        p_maxs_array = np.array(p_maxs_filtered)
        p_medians_array = np.array(p_medians_filtered)
        c_mins_array = np.array(c_mins_filtered)
        c_maxs_array = np.array(c_maxs_filtered)
        c_medians_array = np.array(c_medians_filtered)

        # Remove NaN values from LCD data for plotting
        lcd_valid_idx = ~np.isnan(lcd_medians_array)

        # Plot P values (withdrawal) as min-max shadow and median line
        ax.fill_between(years_array, p_mins_array, p_maxs_array,
                       color='#A6DCC7', alpha=0.3)

        ax.plot(years_array, p_medians_array,
               color='#1B9E77', linewidth=2, alpha=0.8, label='Model withdrawal (median)')

        # Plot C values (consumption) as min-max shadow and median line if available
        c_valid_idx = ~np.isnan(c_medians_array)
        if np.any(c_valid_idx):
            valid_c_years = years_array[c_valid_idx]
            valid_c_mins = c_mins_array[c_valid_idx]
            valid_c_maxs = c_maxs_array[c_valid_idx]
            valid_c_medians = c_medians_array[c_valid_idx]

            ax.fill_between(valid_c_years, valid_c_mins, valid_c_maxs,
                           color='#FFA07A', alpha=0.3)

            ax.plot(valid_c_years, valid_c_medians,
                   color='#FF4500', linewidth=2, alpha=0.8, label='Model consumption (median)')

        # Plot LCD as points with error bars only where we have data
        if np.any(lcd_valid_idx):
            valid_years = years_array[lcd_valid_idx]
            valid_lcd_medians = lcd_medians_array[lcd_valid_idx]
            valid_lcd_stds = lcd_stds_array[lcd_valid_idx]

            ax.errorbar(valid_years, valid_lcd_medians, yerr=valid_lcd_stds,
                       fmt='o', markersize=5, capsize=3,
                       color='#1F3A5F', alpha=0.8, label='Observed Withdrawal (median ± std)')

        # Customize subplot
        ax.set_title(f"{region}", fontsize=12, fontweight='bold')
        #ax.grid(True, linestyle='--', alpha=0.3)
        ax.tick_params(axis='x', rotation=45, labelsize=14)
        ax.tick_params(axis='y', labelsize=14)

        # Set x-axis limits (1990 to 2021)
        ax.set_xlim(1990, 2023)

        # Set axis title font size
        ax.xaxis.label.set_size(18)
        ax.yaxis.label.set_size(18)

        # Add legend at top right corner for each plot
        #ax.legend(fontsize=10, loc='upper left', facecolor='white', framealpha=1)

        # Show x-axis title and numbers only for plots 5, 6, 7 (index 4, 5, 6)
        if idx in [3, 4, 5, 6]:  # Plots 5, 6, 7 (0-indexed)
            ax.set_xlabel('Year', fontsize=18)
            ax.tick_params(axis='x', which='both', bottom=True, labelbottom=True)
        else:
            ax.set_xlabel('', fontsize=18)
            ax.tick_params(axis='x', which='both', bottom=True, labelbottom=True)

        # Always show y-axis label for leftmost plots (indices 0, 3, 6)
        if idx in [0, 4]:
            ax.set_ylabel('Liters/Capita/Day', fontsize=14)

    # Hide empty subplots
    for idx in range(len(unique_regions), len(axes_flat)):
        axes_flat[idx].axis('off')

    # Adjust spacing
    plt.subplots_adjust(hspace=0.3, wspace=0.3)

    outpath = os.path.join(OUTPUT_DIR, "Countries_3x3_Subplots.png")
    plt.savefig(outpath, dpi=600, bbox_inches='tight')
    plt.close()
    print(f"[SAVED] {outpath}")

def create_saudi_subplots(df_saudi):
    """
    Create 4x4 subplots for Saudi regions (Relation='saudi')
    Each subplot shows one region with:
    - LCD_1, LCD_2, LCD_3 combined as single points (median ± std) per year
    - P columns as min-max shadow with median line (withdrawal)
    - C columns as min-max shadow with median line (consumption)
    """
    if df_saudi.empty:
        print("No data for Saudi regions (Relation='saudi')")
        return

    # Get unique regions
    unique_regions = sorted(df_saudi["Region"].unique())

    # Calculate grid size: 4x4 = 16 subplots
    if len(unique_regions) > 16:
        print(f"Warning: Too many regions ({len(unique_regions)}). Showing first 16.")
        unique_regions = unique_regions[:16]

    # Create 4x4 grid
    n_rows, n_cols = 4, 4
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(22, 16), sharex=False, sharey=False)

    # Flatten axes array for easy indexing
    axes_flat = axes.flatten()

    # Create a color map for regions
    region_colors = plt.cm.tab20(np.linspace(0, 1, len(unique_regions)))
    color_dict = dict(zip(unique_regions, region_colors))

    for idx, region in enumerate(unique_regions):
        if idx >= len(axes_flat):
            break

        ax = axes_flat[idx]
        region_data = df_saudi[df_saudi['Region'] == region].sort_values('Year')

        if region_data.empty:
            ax.text(0.5, 0.5, f"No data\nfor {region}",
                   ha='center', va='center', transform=ax.transAxes)
            ax.set_title(region, fontsize=12, fontweight='bold')
            continue

        # Prepare data for plotting
        years = sorted(region_data['Year'].unique())
        lcd_medians = []
        lcd_stds = []

        # Withdrawal data (P columns)
        p_mins = []
        p_maxs = []
        p_medians = []

        # Consumption data (C columns)
        c_mins = []
        c_maxs = []
        c_medians = []

        for year in years:
            year_data = region_data[region_data['Year'] == year]

            # Check if we have complete P data for Saudi (withdrawal)
            has_complete_p = True
            saudi_p_cols = ['P_1R1', 'P_1R2', 'P_1R3', 'P_3R1', 'P_3R2', 'P_3R3']
            for col in saudi_p_cols:
                if col not in year_data.columns or pd.isna(year_data[col].iloc[0]) or year_data[col].iloc[0] == 0:
                    has_complete_p = False
                    break

            # Check if we have complete C data for Saudi (consumption)
            has_complete_c = True
            saudi_c_cols = ['C_1R1', 'C_1R2', 'C_1R3', 'C_2R1', 'C_2R2', 'C_2R3', 'C_3R1', 'C_3R2', 'C_3R3']
            for col in saudi_c_cols:
                if col not in year_data.columns or pd.isna(year_data[col].iloc[0]) or year_data[col].iloc[0] == 0:
                    has_complete_c = False
                    break

            # Skip year if we don't have complete P data (withdrawal is required)
            if not has_complete_p:
                continue

            # Get LCD values (LCD_1, LCD_2, LCD_3) - accept whatever is available
            lcd_values = []
            for col in ['LCD_1', 'LCD_2', 'LCD_3']:
                if col in year_data.columns:
                    value = year_data[col].iloc[0]
                    if pd.notna(value) and value != 0:
                        lcd_values.append(value)

            # Get P values for withdrawal - we know they're all available
            p_values = []
            for col in saudi_p_cols:
                value = year_data[col].iloc[0]
                p_values.append(value)

            # Get C values for consumption if available
            c_values = []
            if has_complete_c:
                for col in saudi_c_cols:
                    value = year_data[col].iloc[0]
                    c_values.append(value)

            # Always add LCD data if we have complete P data
            if lcd_values:
                lcd_medians.append(np.median(lcd_values))
                lcd_stds.append(np.std(lcd_values) if len(lcd_values) > 1 else 0)
            else:
                # If no LCD data, still show P data
                lcd_medians.append(np.nan)
                lcd_stds.append(np.nan)

            # Add P data (withdrawal) - always available since we checked
            p_mins.append(np.min(p_values))
            p_maxs.append(np.max(p_values))
            p_medians.append(np.median(p_values))

            # Add C data (consumption) if available
            if has_complete_c and c_values:
                c_mins.append(np.min(c_values))
                c_maxs.append(np.max(c_values))
                c_medians.append(np.median(c_values))
            else:
                c_mins.append(np.nan)
                c_maxs.append(np.nan)
                c_medians.append(np.nan)

        # Filter years to only those with complete P data
        years_filtered = []
        lcd_medians_filtered = []
        lcd_stds_filtered = []
        p_mins_filtered = []
        p_maxs_filtered = []
        p_medians_filtered = []
        c_mins_filtered = []
        c_maxs_filtered = []
        c_medians_filtered = []

        for i, year in enumerate(years):
            # Only include years where we have P data
            if i < len(p_mins):  # This means we have P data for this year
                years_filtered.append(year)
                lcd_medians_filtered.append(lcd_medians[i] if i < len(lcd_medians) else np.nan)
                lcd_stds_filtered.append(lcd_stds[i] if i < len(lcd_stds) else np.nan)
                p_mins_filtered.append(p_mins[i])
                p_maxs_filtered.append(p_maxs[i])
                p_medians_filtered.append(p_medians[i])
                c_mins_filtered.append(c_mins[i] if i < len(c_mins) else np.nan)
                c_maxs_filtered.append(c_maxs[i] if i < len(c_maxs) else np.nan)
                c_medians_filtered.append(c_medians[i] if i < len(c_medians) else np.nan)

        if not years_filtered:
            ax.text(0.5, 0.5, f"No complete P data\nfor {region}",
                   ha='center', va='center', transform=ax.transAxes)
            ax.set_title(region, fontsize=12, fontweight='bold')
            continue

        # Convert to numpy arrays
        years_array = np.array(years_filtered)
        lcd_medians_array = np.array(lcd_medians_filtered)
        lcd_stds_array = np.array(lcd_stds_filtered)
        p_mins_array = np.array(p_mins_filtered)
        p_maxs_array = np.array(p_maxs_filtered)
        p_medians_array = np.array(p_medians_filtered)
        c_mins_array = np.array(c_mins_filtered)
        c_maxs_array = np.array(c_maxs_filtered)
        c_medians_array = np.array(c_medians_filtered)

        # Remove NaN values from LCD data for plotting
        lcd_valid_idx = ~np.isnan(lcd_medians_array)

        # Plot P values (withdrawal) as min-max shadow and median line
        ax.fill_between(years_array, p_mins_array, p_maxs_array,
                       color='#A6DCC7', alpha=0.3)

        ax.plot(years_array, p_medians_array,
               color='#1B9E77', linewidth=2, alpha=0.8, label='Model withdrawal (median)')

        # Plot C values (consumption) as min-max shadow and median line if available
        c_valid_idx = ~np.isnan(c_medians_array)
        if np.any(c_valid_idx):
            valid_c_years = years_array[c_valid_idx]
            valid_c_mins = c_mins_array[c_valid_idx]
            valid_c_maxs = c_maxs_array[c_valid_idx]
            valid_c_medians = c_medians_array[c_valid_idx]

            ax.fill_between(valid_c_years, valid_c_mins, valid_c_maxs,
                           color='#FFA07A', alpha=0.3)

            ax.plot(valid_c_years, valid_c_medians,
                   color='#FF4500', linewidth=2, alpha=0.8, label='Model consumption (median)')

        # Plot LCD as points with error bars only where we have data
        if np.any(lcd_valid_idx):
            valid_years = years_array[lcd_valid_idx]
            valid_lcd_medians = lcd_medians_array[lcd_valid_idx]
            valid_lcd_stds = lcd_stds_array[lcd_valid_idx]

            ax.errorbar(valid_years, valid_lcd_medians, yerr=valid_lcd_stds,
                       fmt='o', markersize=5, capsize=3,
                       color='#1F3A5F', alpha=0.8, label='Observed Withdrawal (median ± std)')

        # Customize subplot
        ax.set_title(f"{region}", fontsize=12, fontweight='bold')
        #ax.grid(True, linestyle='--', alpha=0.3)
        ax.tick_params(axis='x', rotation=45, labelsize=12)
        ax.tick_params(axis='y', labelsize=12)

        # Set x-axis limits (1990 to 2021)
        ax.set_xlim(1990, 2023)

        # Set axis title font size
        ax.xaxis.label.set_size(12)
        ax.yaxis.label.set_size(12)

        # Add legend at top right corner for each plot
        #ax.legend(fontsize=10, loc='upper left', facecolor='white', framealpha=1)

        # Show x-axis title and numbers only for bottom row plots
        # For 4x4 grid, bottom row indices are 12, 13, 14, 15
        if idx in [12, 13, 14, 15]:
            ax.set_xlabel('Year', fontsize=12)
            ax.tick_params(axis='x', which='both', bottom=True, labelbottom=True)
        else:
            ax.set_xlabel('', fontsize=12)
            ax.tick_params(axis='x', which='both', bottom=True, labelbottom=True)

        # Always show y-axis label for leftmost plots (indices 0, 4, 8, 12)
        if idx in [0, 4, 8, 12]:
            ax.set_ylabel('Liters/Capita/Day', fontsize=12)

    # Hide empty subplots
    for idx in range(len(unique_regions), len(axes_flat)):
        axes_flat[idx].axis('off')

    # Adjust spacing
    plt.subplots_adjust(hspace=0.3, wspace=0.3)

    outpath = os.path.join(OUTPUT_DIR, "Saudi_Regions_4x4_Subplots.png")
    plt.savefig(outpath, dpi=600, bbox_inches='tight')
    plt.close()
    print(f"[SAVED] {outpath}")

def process_relation_no(df_relation):
    """
    Process rows where Relation is 'no'.
    Observed: LCD_1, LCD_2, LCD_3 (accept partial data)
    Predicted: P_1, P_2, P_3 (require all three)
    """
    results = []

    for idx, row in df_relation.iterrows():
        # NEW: Only require ALL P columns to be non-zero and non-NA
        predicted_cols = ['P_1', 'P_2', 'P_3']

        # Check if we have complete P data
        has_complete_p = True
        for col in predicted_cols:
            if pd.isna(row[col]) or row[col] == 0:
                has_complete_p = False
                break

        if not has_complete_p:
            continue

        # For LCD columns, accept whatever is available
        observed_cols = ['LCD_1', 'LCD_2', 'LCD_3']
        observed_values = []
        for col in observed_cols:
            if pd.notna(row[col]) and row[col] != 0:
                observed_values.append(row[col])

        # Get predicted values (we know they're all available)
        predicted_values = [row[col] for col in predicted_cols]

        # Calculate statistics
        result = {
            'Region': row['Region'],
            'Year': row['Year'],
            'Observed_mean': np.median(observed_values) if observed_values else np.nan,
            'Observed_std': np.std(observed_values, ddof=1) if len(observed_values) > 1 else 0,
            'Predicted_mean': np.median(predicted_values),
            'Predicted_std': np.std(predicted_values, ddof=1) if len(predicted_values) > 1 else 0,
            'Relation': row['Relation']
        }
        results.append(result)

    return pd.DataFrame(results).dropna(subset=['Observed_mean', 'Predicted_mean'])

def process_relation_saudi(df_relation):
    """
    Process rows where Relation is 'saudi'.
    Observed: LCD_1, LCD_2, LCD_3 (accept partial data)
    Predicted: P_1R1, P_1R2, P_1R3, P_3R1, P_3R2, P_3R3 (require all six)
    """
    results = []

    for idx, row in df_relation.iterrows():
        # Predicted columns (require all six for Saudi)
        predicted_cols = ['P_1R1', 'P_1R2', 'P_1R3', 'P_3R1', 'P_3R2', 'P_3R3']

        # Check if we have complete P data
        has_complete_p = True
        for col in predicted_cols:
            if pd.isna(row[col]) or row[col] == 0:
                has_complete_p = False
                break

        if not has_complete_p:
            continue

        # For LCD columns, accept whatever is available
        observed_cols = ['LCD_1', 'LCD_2', 'LCD_3']
        observed_values = []
        for col in observed_cols:
            if pd.notna(row[col]) and row[col] != 0:
                observed_values.append(row[col])

        # Get predicted values (we know they're all available)
        predicted_values = [row[col] for col in predicted_cols]

        # Calculate statistics
        result = {
            'Region': row['Region'],
            'Year': row['Year'],
            'Observed_mean': np.median(observed_values) if observed_values else np.nan,
            'Observed_std': np.std(observed_values, ddof=1) if len(observed_values) > 1 else 0,
            'Predicted_mean': np.median(predicted_values),
            'Predicted_std': np.std(predicted_values, ddof=1) if len(predicted_values) > 1 else 0,
            'Relation': row['Relation']
        }
        results.append(result)

    return pd.DataFrame(results).dropna(subset=['Observed_mean', 'Predicted_mean'])

def export_3yr_median_predicted_from_raw(df, output_dir, relation='no', filename="Countries_3yr_median_predicted.csv"):
    """
    Export median predicted values for each country/region in 3-year increments
    directly from the raw dataframe, ignoring filtering issues.

    Parameters:
        df (pd.DataFrame): Original dataframe with raw P or P_R columns.
        output_dir (str): Folder to save CSV.
        relation (str): 'no' for countries, 'saudi' for Saudi regions.
        filename (str): Output CSV name.
    """
    import pandas as pd
    import os
    import numpy as np

    os.makedirs(output_dir, exist_ok=True)

    # Define years in 3-year increments
    years_3yr = list(range(1990, 2023, 3))

    # Filter dataframe by Relation
    df_rel = df[df['Relation'] == relation].copy()
    if df_rel.empty:
        print(f"No data for Relation='{relation}'")
        return

    # Determine predicted columns
    if relation == 'no':
        #pred_cols = ['P_1', 'P_2', 'P_3']
        pred_cols = ['C_1', 'C_2', 'C_3']
    elif relation == 'saudi':
        #pred_cols = ['P_1R1', 'P_1R2', 'P_1R3', 'P_3R1', 'P_3R2', 'P_3R3']
        pred_cols = ['C_1R1', 'C_1R2', 'C_1R3', 'C_3R1', 'C_3R2', 'C_3R3']
    else:
        raise ValueError("Relation must be 'no' or 'saudi'")

    # Unique regions
    regions = sorted(df_rel['Region'].unique())
    result = pd.DataFrame({'Country': regions})

    # Calculate median predicted values per year
    for year in years_3yr:
        df_year = df_rel[df_rel['Year'] == year]
        medians = []
        for region in regions:
            df_reg = df_year[df_year['Region'] == region]
            if df_reg.empty:
                medians.append(np.nan)
            else:
                # Take median across all predicted columns for this region/year
                values = df_reg[pred_cols].values.flatten()
                # Only non-NA, non-zero
                values = values[~np.isnan(values)]
                values = values[values != 0]
                if len(values) == 0:
                    medians.append(np.nan)
                else:
                    medians.append(np.median(values))
        result[str(year)] = medians

    # Save CSV
    outpath = os.path.join(output_dir, filename)
    result.to_csv(outpath, index=False)
    print(f"[SAVED] 3-year median predicted CSV: {outpath}")
    return result


def main():
    try:
        # Load the Excel file
        print(f"Loading data from: {INPUT_PATH}")
        df = pd.read_excel(INPUT_PATH)
        print(f"Loaded data with {len(df)} rows and {len(df.columns)} columns")

        # Clean the 'Relation' column
        if 'Relation' in df.columns:
            df['Relation'] = df['Relation'].astype(str).str.lower().str.strip()
            print(f"Unique relations: {df['Relation'].unique()}")
        else:
            print("Error: 'Relation' column not found in data")
            return

        # Check for required columns
        required_cols = ['Region', 'Year']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            print(f"Error: Missing required columns: {missing_cols}")
            return

        # Separate data by relation type
        df_no = df[df['Relation'] == 'no'].copy()
        df_saudi = df[df['Relation'] == 'saudi'].copy()

        print(f"\nRows with Relation='no': {len(df_no)}")
        print(f"Rows with Relation='saudi': {len(df_saudi)}")

        # Create subplot grids
        print("\n" + "="*50)
        print("Creating 3x3 subplots for countries (Relation='no')...")
        create_country_subplots(df_no)

        print("\n" + "="*50)
        print("Creating 4x4 subplots for Saudi regions (Relation='saudi')...")
        create_saudi_subplots(df_saudi)

        # Process for comparison plots
        print("\n" + "="*50)
        print("Processing for comparison plots...")
        processed_no = process_relation_no(df_no)
        processed_saudi = process_relation_saudi(df_saudi)

        print(f"Processed {len(processed_no)} rows for Relation='no'")
        print(f"Processed {len(processed_saudi)} rows for Relation='saudi'")

        # Combine all processed data
        all_processed = pd.concat([processed_no, processed_saudi], ignore_index=True)

        # Create comparison plots
        print("\n" + "="*50)
        print("Creating comparison scatter plots...")

        # Relation = No: 0-450
        if not processed_no.empty:
            plot_pred_vs_obs_new(
                processed_no,
                "Countries (Relation = No)",
                "Type2_Pred_vs_Obs_Relation_No.png",
                xlim=(0, 500),
                ylim=(0, 500)
            )
        else:
            print("No data for Relation='no' comparison plot")

        # Relation = Saudi: 0-400
        if not processed_saudi.empty:
            plot_pred_vs_obs_new(
                processed_saudi,
                "Saudi Regions (Relation = Saudi)",
                "Type2_Pred_vs_Obs_Relation_Saudi.png",
                xlim=(0, 500),
                ylim=(0, 500)
            )
        else:
            print("No data for Relation='saudi' comparison plot")

        # All regions: 0-450
        if not all_processed.empty:
            plot_pred_vs_obs(
                all_processed,
                "Predicted vs Observed (All Regions)",
                "Type2_Pred_vs_Obs_All.png",
                xlim=(0, 500),
                ylim=(0, 500)
            )
        else:
            print("No data for all regions comparison plot")

        # Save processed data
        output_csv = os.path.join(OUTPUT_DIR, "processed_data.csv")
        all_processed.to_csv(output_csv, index=False)
        print(f"\n[SAVED] Processed data to {output_csv}")

        # Print summary
        print("\n" + "="*50)
        print("SUMMARY")
        print("="*50)
        print(f"Output directory: {OUTPUT_DIR}")
        print(f"\nFiles created:")
        print(f"  1. Countries_3x3_Subplots.png")
        print(f"  2. Saudi_Regions_4x4_Subplots.png")
        if len(df_no['Region'].unique()) > 9:
            print(f"  3. Countries_Page_2.png, etc.")
        if len(df_saudi['Region'].unique()) > 16:
            print(f"  4. Saudi_Page_2.png, etc.")
        print(f"  5. Type2_Pred_vs_Obs_Relation_No.png")
        print(f"  6. Type2_Pred_vs_Obs_Relation_Saudi.png")
        print(f"  7. Type2_Pred_vs_Obs_All.png")
        print(f"  8. processed_data.csv")
        print("\nNote: Years are only shown if complete P data is available.")
        print("LCD data is shown wherever available (partial data accepted).")
        print("Consumption (C) data is shown only when complete data is available.")

        # Countries
        export_3yr_median_predicted_from_raw(df, OUTPUT_DIR, relation='no', filename="Countries_3yr_median_predicted.csv")

        # Saudi regions
        export_3yr_median_predicted_from_raw(df, OUTPUT_DIR, relation='saudi', filename="Saudi_Regions_3yr_median_predicted.csv")


    except FileNotFoundError:
        print(f"Error: File '{INPUT_PATH}' not found.")
        print("Please check the file path.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
