# Domestic sector

Domestic water withdrawal and consumption, 1990–2025 (Sect. 2.2 of the paper).

## Files

| File | Use |
|---|---|
| `Domestic_Data_Set.xlsx` | Observed per-capita use (L per capita per day), household size, GDP per capita, connection rate and non-revenue water by country and Saudi region |
| `Domestic_Model_Used_For_Gridding.py` | Predicts per-capita use for every region and year and distributes domestic withdrawal over the urban and rural population grid |
| `Uncertenity_Calculator.py` | Predicts per-capita use and domestic withdrawal and consumption with their uncertainty ranges; writes `Output/LCD_Predictions_With_withdrawal_Uncertainty.xlsx` |
| `Uncertenity_Grapher.py` | Plots the predicted withdrawal and consumption with their uncertainty against the observations |

Run `Uncertenity_Calculator.py` before `Uncertenity_Grapher.py`. All outputs are written to `Output/`.

## Spatial data

| Folder | Content | Source |
|---|---|---|
| `Spatial_Data/GHSL_urban_rural_3arcsec/` | `urban_<year>.tif`, urban and rural cells | GHSL degree of urbanisation (GHS-SMOD), Schiavina et al. (2023) |
| `Spatial_Data/Population_Rasters/` | `pop<year>_raster.tif`, population per cell | GHSL population (GHS-POP), Schiavina et al. (2023), scaled to national totals |
| `Spatial_Data/Population_Rasters_Clipped/` | `pop<year>_clipped.tif`, the same grids clipped to the domain | as above |
| `Spatial_Data/Region_Masks/` | `<region>.tif`, one mask per country or Saudi region | national and regional boundaries |

The GHSL data are available at https://human-settlement.emergency.copernicus.eu.
