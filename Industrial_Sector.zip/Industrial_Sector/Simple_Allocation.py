import os
import math
import glob
from pathlib import Path
from collections import defaultdict
import concurrent.futures
from functools import lru_cache

import numpy as np
import pandas as pd
import rasterio
from rasterio.transform import from_origin
from rasterio.features import rasterize
import geopandas as gpd
from shapely.geometry import Point, box
from shapely.affinity import scale as shp_scale

import pickle
import hashlib
import time

import matplotlib.pyplot as plt
from scipy import ndimage
from scipy import sparse

plt.rcParams['font.family'] = ['DejaVu Sans']

# -----------------------------
# CONFIGURATION
# -----------------------------
ROOT = r"/home/alzubiah/Projection"
TEMPLATE_TIF = os.path.join(ROOT, "All_zero_clip.tif")
SUBSECTORS = [
    "Power_Generation",
    "Petro_Ref",
    "PetroChem",
    "Steel",
    "Aluminium",
    "Cement",
    "Paper_Pulp",
    "Food_Bev",
    "Oil_Extraction",
    "Mining",
    "Potash",
    "Other",
]

WRITE_TIF_OUTPUT = False
CREATE_VISUALIZATIONS = True
DEBUG_MODE = True
OTHER_SECTOR_PERCENTAGE = 0.05

WATER_ALLOCATION_FILE = os.path.join(ROOT, "02_predicted_wwi_summary.xlsx")

SUBSECTOR_WITHDRAWAL_CONSTANTS = {
    "Petro_Ref": (1.5/1000),        # thousand m3 crude
    "PetroChem": (3.2),             # Mt
    "Steel": (24/1000),             # thousand t (was 24.8)
    "Aluminium": (24/1000000),      # t (was 24.8)
    "Cement": (0.279/1000),         # thousand t
    "Paper_Pulp": (7.62/1000000),   # t
    "Food_Bev": 1.0,                # country values below
    "Oil_Extraction": (1.84/1000000),   # m3 oil  (was 1.96)
    "Mining": (2.14/1000000),       # t
    "Potash": (4.83/1000000),       # t
    "Other": 1.0,                   # 5 % rule, computed separately
}

SUBSECTOR_CONSUMPTION_CONSTANTS = {
    "Petro_Ref": (0.96/1000),
    "PetroChem": (1.6),
    "Steel": (4/1000),
    "Aluminium": (4/1000000),
    "Cement": (0.163/1000),
    "Paper_Pulp": (1.25/1000000),
    "Food_Bev": 1.0,
    "Oil_Extraction": (1.84/1000000),   # m3 oil, same as withdrawal (was 0.69)
    "Mining": (0.77/1000000),
    "Potash": (3.14/1000000),
    "Other": 0,
}

FOOD_BEV_WITHDRAWAL_CONSTANTS = {
    "Jordan": (2.9/1000000),
    "Oman": (8.6/1000000),
    "Qatar": (12.0/1000000),
    "Bahrain": (13.3/1000000),
    "Kuwait": (11.8/1000000),
    "Saudi": (10.3/1000000),
    "Uae": (11.1/1000000),
}

FOOD_BEV_CONSUMPTION_CONSTANTS = {c: 0.42 * v for c, v in FOOD_BEV_WITHDRAWAL_CONSTANTS.items()}

# Output in Mm3, same as the other dictionaries (divisor = production unit)
SEA_WATER_COOLING_RATES_WITHDRAWAL = {
    "Petro_Ref": 40/1000,           # was 45, thousand m3 crude
    "PetroChem": 80.0,              # Mt
    "Steel": 70.0/1000,             # thousand t
    "Aluminium": 70.0/1000000,      # t
    "Potash": 42/1000000,        
}

SEA_WATER_COOLING_RATES_CONSUMPTION = {
    "Petro_Ref": 0.0,
    "PetroChem": 0.0,
    "Steel": 0.0,
    "Aluminium": 0.0,
    "Potash": 0.0,         # t
}

POWER_GEN_WITHDRAWAL_COEFFICIENTS = {
    'Sea': 43.0/1000000,            # was 42 (Table 3)
    'Fresh': 0.97/1000000,          # was 0.89 (Table 3)
    'Reused': 0.97/1000000,
    'Dry': 0.008/1000000,           # Table 3; was 0
    'Renewable': 0.0
}

POWER_GEN_CONSUMPTION_COEFFICIENTS = {
    'Sea': 0.378541/1000000,
    'Fresh': 0.776009/1000000,
    'Reused': 0.776009/1000000,
    'Dry': 0.008/1000000,           # Table 3; was 0
    'Renewable': 0.0
}
YEARS = list(range(1990, 2026))


OUT_DIR = os.path.join(ROOT, "Run_v6_coastal")   # everything from this version goes here
OUT_TIF = os.path.join(OUT_DIR, "tifs")
OUT_PNG = os.path.join(OUT_DIR, "pngs")
LOG_DIR = os.path.join(OUT_DIR, "logs")
OTHERS_FOLDER = os.path.join(ROOT, "Other")
DETAILED_OUTPUT_DIR = os.path.join(OUT_DIR, "detailed_outputs")

# Sea-water cooling is only applied to plants within this distance of the coast.
# 25 km: Jubail (SATORP, Sadara, ArcelorMittal) and Sohar Aluminium sit 11-19 km from the
# Natural Earth coastline but use seawater supply; the next-closest plant is 105 km away
# (Dead Sea potash, a lake), so any value between ~20 and ~100 km gives the same result.
COAST_DISTANCE_KM = 25.0
NATURAL_EARTH_DIR = os.path.join(ROOT, "Natural_Earth")   # ne_10m_land + ne_10m_admin_0_countries shapefiles

os.makedirs(OUT_TIF, exist_ok=True)
os.makedirs(OUT_PNG, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(DETAILED_OUTPUT_DIR, exist_ok=True)

# -----------------------------
# CACHE
# -----------------------------
MODEL_DATA_CACHE = {}
PLANT_DATA_CACHE = {}
RASTER_META_CACHE = {}
WATER_ALLOCATION_MULTIPLIERS = {}

COUNTRY_LIST = ["Saudi", "Qatar", "Bahrain", "Oman", "Uae", "Kuwait", "Jordan"]

NO_WWI_MULTIPLIER_SECTORS = [
    "Oil_Extraction",
    "Power_Generation",
]

# -----------------------------
# DEBUG FUNCTION
# -----------------------------
def debug_log(message, level="INFO"):
    if DEBUG_MODE:
        timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] [{level}] {message}", flush=True)

# -----------------------------
# UTILITY FUNCTIONS
# -----------------------------
def load_water_allocation_multipliers():
    global WATER_ALLOCATION_MULTIPLIERS
    
    if not os.path.exists(WATER_ALLOCATION_FILE):
        debug_log(f"Water allocation file not found", "WARNING")
        return {}
    
    try:
        df = pd.read_excel(WATER_ALLOCATION_FILE)
        for _, row in df.iterrows():
            country = str(row['Country']).strip()
            year = int(row['Year'])
            wwi_median = float(row['WWI_median'])
            
            if country not in WATER_ALLOCATION_MULTIPLIERS:
                WATER_ALLOCATION_MULTIPLIERS[country] = {}
            WATER_ALLOCATION_MULTIPLIERS[country][year] = wwi_median
        
        debug_log(f"Loaded water multipliers for {len(WATER_ALLOCATION_MULTIPLIERS)} countries", "INFO")
        extrapolate_water_multipliers()
        return WATER_ALLOCATION_MULTIPLIERS
    except Exception as e:
        debug_log(f"Error loading water allocation file: {e}", "ERROR")
        return {}

def extrapolate_water_multipliers(fit_years=5, ref_years=10):
    """The WWI file stops before the last model year (2025 was silently falling back to 1.0).
    For each country: straight-line fit through the last `fit_years` values, extended forward,
    clipped to the min/max of the last `ref_years` values so it can never run away."""
    last_needed = max(YEARS)
    rows = []
    for country, series in WATER_ALLOCATION_MULTIPLIERS.items():
        years = sorted(series)
        if len(years) < fit_years:
            continue
        last = years[-1]
        fit_y = np.array(years[-fit_years:], dtype=float)
        fit_v = np.array([series[y] for y in years[-fit_years:]])
        slope, intercept = np.polyfit(fit_y, fit_v, 1)
        ref_v = [series[y] for y in years[-ref_years:]]
        lo, hi = min(ref_v), max(ref_v)
        for y in range(last + 1, last_needed + 1):
            val = float(np.clip(slope * y + intercept, lo, hi))
            series[y] = val
            rows.append({'Country': country, 'Year': y, 'WWI_extrapolated': val,
                         'last_observed_year': last, 'last_observed_value': series[last],
                         'fit_slope_per_year': slope})
    if rows:
        out = pd.DataFrame(rows)
        os.makedirs(OUT_DIR, exist_ok=True)
        out.to_excel(os.path.join(OUT_DIR, "extrapolated_multipliers.xlsx"), index=False)
        for r in rows:
            if r['Country'] in COUNTRY_LIST:
                debug_log(f"Extrapolated WWI {r['Country']} {r['Year']}: {r['WWI_extrapolated']:.4f} "
                          f"(last observed {r['last_observed_year']}: {r['last_observed_value']:.4f})", "INFO")

def get_water_multiplier(country, year):
    if not WATER_ALLOCATION_MULTIPLIERS:
        load_water_allocation_multipliers()
    
    try:
        if country in WATER_ALLOCATION_MULTIPLIERS:
            if year in WATER_ALLOCATION_MULTIPLIERS[country]:
                return WATER_ALLOCATION_MULTIPLIERS[country][year]
        
        for stored_country in WATER_ALLOCATION_MULTIPLIERS.keys():
            if stored_country.lower() == country.lower():
                if year in WATER_ALLOCATION_MULTIPLIERS[stored_country]:
                    return WATER_ALLOCATION_MULTIPLIERS[stored_country][year]
        
        return 1.0
    except:
        return 1.0

@lru_cache(maxsize=1000)
def parse_coord_from_colname(name):
    import re
    s = str(name).strip()
    match = re.match(r'\(([-+]?\d*\.\d+),\s*([-+]?\d*\.\d+)\)', s)
    if match:
        try:
            lat = float(match.group(1))
            lon = float(match.group(2))
            return (lon, lat)
        except:
            return None
    return None

def read_template_raster(path):
    if path in RASTER_META_CACHE:
        meta = RASTER_META_CACHE[path]['meta'].copy()
        return meta, np.zeros((meta["height"], meta["width"]), dtype=np.float32)
    
    with rasterio.open(path) as src:
        meta = src.meta.copy()
        RASTER_META_CACHE[path] = {'meta': meta.copy()}
        return meta, np.zeros((meta["height"], meta["width"]), dtype=np.float32)

def write_raster(path, arr, meta):
    if not WRITE_TIF_OUTPUT:
        return
    
    try:
        out_meta = meta.copy()
        out_meta.update({'dtype': rasterio.float32, 'count': 1, 'compress': 'lzw'})
        with rasterio.open(path, "w", **out_meta) as dst:
            dst.write(arr.astype(np.float32), 1)
        debug_log(f"Raster saved: {path}", "INFO")
    except Exception as e:
        debug_log(f"Error writing raster {path}: {e}", "ERROR")

def safe_float(val):
    if pd.isna(val):
        return 0.0
    if isinstance(val, (int, float, np.number)):
        return float(val)
    return 0.0

# -----------------------------
# COASTLINE / BASEMAP (Natural Earth, public domain)
# -----------------------------
_NE_CACHE = {}
_COAST_DIST_CACHE = {}

def load_natural_earth():
    """Load land polygons, country polygons and the coastline once."""
    if "land" not in _NE_CACHE:
        land = gpd.read_file(os.path.join(NATURAL_EARTH_DIR, "ne_10m_land.shp"))
        countries = gpd.read_file(os.path.join(NATURAL_EARTH_DIR, "ne_10m_admin_0_countries.shp"))
        # Land polygons carry no internal borders, so their outline is the coastline
        # (lakes such as the Dead Sea are land here, the Gulf / Red Sea are sea).
        aoi = box(20, 5, 70, 45)
        coast = land.boundary.unary_union.intersection(aoi)
        _NE_CACHE.update(land=land, countries=countries, coast=coast)
    return _NE_CACHE

def distance_to_coast_km(lon, lat):
    """Distance in km from (lon, lat) to the nearest coastline (local equirectangular approximation)."""
    key = (round(lon, 5), round(lat, 5))
    if key in _COAST_DIST_CACHE:
        return _COAST_DIST_CACHE[key]
    coast = load_natural_earth()["coast"]
    dist = float("inf")
    for half in (0.25, 1.0, 4.0):          # widen the search window until a coastline is found
        local = coast.intersection(box(lon - half, lat - half, lon + half, lat + half))
        if not local.is_empty:
            fx, fy = 111.32 * math.cos(math.radians(lat)), 110.57
            dist = shp_scale(Point(lon, lat), fx, fy, origin=(0, 0)).distance(
                shp_scale(local, fx, fy, origin=(0, 0)))
            break
    _COAST_DIST_CACHE[key] = dist
    return dist

def is_coastal(lon, lat):
    return distance_to_coast_km(lon, lat) <= COAST_DISTANCE_KM

def add_sea_cooling(detailed_country_data, subsector, country, year, lon, lat, plant_production, transform):
    """Sea-water cooling for ONE plant: only if it is within COAST_DISTANCE_KM of the coast."""
    rate = SEA_WATER_COOLING_RATES_WITHDRAWAL.get(subsector, 0)
    if rate <= 0 or plant_production <= 0:
        return
    dist = distance_to_coast_km(lon, lat)
    entry = detailed_country_data[subsector][country]
    entry.setdefault('plants_checked', 0)
    entry['plants_checked'] += 1
    if dist > COAST_DISTANCE_KM:
        debug_log(f"  {subsector} {country} plant ({lon:.3f},{lat:.3f}) is {dist:.1f} km from coast -> no sea cooling", "DEBUG")
        return
    entry.setdefault('sea_plants', []).append({
        'lon': lon, 'lat': lat, 'dist_km': dist,
        'withdrawal': plant_production * rate,
        'consumption': plant_production * SEA_WATER_COOLING_RATES_CONSUMPTION.get(subsector, 0),
    })
    debug_log(f"  {subsector} {country} plant ({lon:.3f},{lat:.3f}) is {dist:.1f} km from coast -> SEA cooling {plant_production * rate:.4f}", "DEBUG")

# -----------------------------
# DATA LOADING
# -----------------------------
def preload_all_data():
    global MODEL_DATA_CACHE, PLANT_DATA_CACHE
    
    debug_log("Preloading data...", "INFO")
    load_water_allocation_multipliers()
    
    # Load model data
    for subsector in SUBSECTORS:
        if subsector == "Other":
            continue
            
        model_path = os.path.join(ROOT, subsector, "model_input_data", "production.xlsx")
        if os.path.exists(model_path):
            try:
                df = pd.read_excel(model_path, sheet_name="Sheet1")
                df.columns = [str(col).strip() for col in df.columns]
                MODEL_DATA_CACHE[subsector] = df
                debug_log(f"Loaded model: {subsector}", "DEBUG")
            except Exception as e:
                debug_log(f"Error loading {subsector}: {e}", "ERROR")
    
    # Load plant data
    for subsector in SUBSECTORS:
        if subsector in ["Other", "Power_Generation"]:
            continue
            
        plant_folder = os.path.join(ROOT, subsector, "plant_capacity_location")
        if not os.path.exists(plant_folder):
            continue
            
        for country_file in glob.glob(os.path.join(plant_folder, "*.xlsx")):
            country = os.path.basename(country_file).replace('.xlsx', '')
            try:
                df = pd.read_excel(country_file)
                key = f"{subsector}_{country}"
                PLANT_DATA_CACHE[key] = df
                debug_log(f"Loaded plants: {key}", "DEBUG")
            except Exception as e:
                debug_log(f"Error loading {country_file}: {e}", "ERROR")
    
    debug_log("Data preloading complete!", "INFO")

def get_model_value(subsector, country, year):
    if subsector not in MODEL_DATA_CACHE:
        return 0.0
    
    df = MODEL_DATA_CACHE[subsector]
    
    if country in df.columns:
        year_data = df[df["Year"] == year]
        if not year_data.empty:
            value = year_data[country].iloc[0]
            return float(value) if not pd.isna(value) else 0.0
    
    return 0.0

def get_plant_capacities(subsector, country, year):
    key = f"{subsector}_{country}"
    
    if key not in PLANT_DATA_CACHE:
        for stored_key in PLANT_DATA_CACHE:
            if stored_key.lower() == key.lower():
                key = stored_key
                break
        else:
            return {}, 0.0
    
    df = PLANT_DATA_CACHE[key]
    
    year_col = None
    for col in df.columns:
        if str(col).strip().lower() == "year":
            year_col = col
            break
    
    if year_col is None:
        return {}, 0.0
    
    year_data = df[df[year_col] == year]
    if year_data.empty:
        return {}, 0.0
    
    capacities = {}
    total = 0.0
    
    for col in df.columns:
        if col != year_col:
            cap = safe_float(year_data[col].iloc[0])
            if cap > 0:
                capacities[col] = cap
                total += cap
    
    return capacities, total

# -----------------------------
# CORE ALLOCATION - ONE POINT PER PLANT
# -----------------------------
def add_plant_point(master_withdrawal, master_consumption, row, col, withdrawal, consumption, 
                   plant_allocated_mask, country, subsector, year, transform, plant_data_list, water_type):
    """Add a single point for a plant (not 9 cells)"""
    
    if 0 <= row < master_withdrawal.shape[0] and 0 <= col < master_withdrawal.shape[1]:
        master_withdrawal[row, col] += withdrawal
        master_consumption[row, col] += consumption
        plant_allocated_mask[row, col] = True
        
        lon = transform[2] + col * transform[0]
        lat = transform[5] + row * transform[4]
        
        plant_data_list.append({
            'subsector': subsector,
            'country': country,
            'lon': lon,
            'lat': lat,
            'withdrawal': withdrawal,
            'consumption': consumption,
            'water_type': water_type,
            'year': year
        })

def allocate_power_generation(year, meta, plant_allocated_mask, plant_data_list, master_withdrawal, master_consumption):
    """Power generation allocation - one point per plant"""
    
    debug_log(f"Allocating Power_Generation {year}", "INFO")
    
    totals_by_country = {'withdrawal': defaultdict(float), 'consumption': defaultdict(float)}
    
    plant_folder = os.path.join(ROOT, "Power_Generation", "plant_capacity_location", "processed")
    model_path = os.path.join(ROOT, "Power_Generation", "model_input_data", "production.xlsx")
    
    if not os.path.exists(model_path):
        return totals_by_country
    
    elec_df = pd.read_excel(model_path)
    elec_df.columns = [str(col).strip() for col in elec_df.columns]
    countries = [col for col in elec_df.columns if col.lower() != "year"]
    
    transform = meta["transform"]
    
    for country in countries:
        year_data = elec_df[elec_df["Year"] == year]
        if year_data.empty:
            continue
        
        country_elec = year_data[country].iloc[0]
        if pd.isna(country_elec) or country_elec == 0:
            continue
        
        if "Power_Generation" in NO_WWI_MULTIPLIER_SECTORS:
            water_multiplier = 1.0
        else:
            water_multiplier = get_water_multiplier(country, year)
        
        plant_path = os.path.join(plant_folder, f"{country}.xlsx")
        cooling_path = os.path.join(plant_folder, f"{country}_cooling_types.xlsx")
        
        if not os.path.exists(plant_path) or not os.path.exists(cooling_path):
            continue
        
        capacity_df = pd.read_excel(plant_path)
        cooling_df = pd.read_excel(cooling_path)
        
        year_caps = capacity_df[capacity_df["Year"] == year]
        if year_caps.empty:
            continue
        
        cooling_map = {row['Coordinate']: row['Cooling_Type'] for _, row in cooling_df.iterrows()}
        
        plant_cols = [col for col in capacity_df.columns if col != "Year"]
        total_capacity = sum(year_caps[col].iloc[0] if col in year_caps.columns else 0 for col in plant_cols)
        
        if total_capacity == 0:
            continue
        
        for plant_col in plant_cols:
            capacity = year_caps[plant_col].iloc[0] if plant_col in year_caps.columns else 0
            if capacity <= 0:
                continue
            
            cooling_type = cooling_map.get(plant_col, "Fresh")
            plant_share = capacity / total_capacity
            plant_elec = country_elec * plant_share
            
            withdrawal_coef = POWER_GEN_WITHDRAWAL_COEFFICIENTS.get(cooling_type, 0.89)
            consumption_coef = POWER_GEN_CONSUMPTION_COEFFICIENTS.get(cooling_type, 0.45)
            
            withdrawal = plant_elec * withdrawal_coef *    water_multiplier
            consumption = plant_elec * consumption_coef *  water_multiplier
            
            if withdrawal > 0:
                coord = parse_coord_from_colname(plant_col)
                if coord:
                    col_idx = int(round((coord[0] - transform[2]) / transform[0]))
                    row_idx = int(round((coord[1] - transform[5]) / transform[4]))
                    
                    water_type = f"Power_{cooling_type}"
                    
                    add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                  withdrawal, consumption, plant_allocated_mask, country,
                                  "Power_Generation", year, transform, plant_data_list, water_type)
                    
                    totals_by_country['withdrawal'][country] += withdrawal
                    totals_by_country['consumption'][country] += consumption
    
    return totals_by_country

def allocate_industrial_subsector(subsector, year, meta, plant_allocated_mask, plant_data_list,
                                  master_withdrawal, master_consumption, detailed_country_data):
    """Industrial subsector allocation - with special handling for Mining cluster-based allocation"""
    
    # Use cluster-based allocation for Mining
    if subsector == "Mining":
        return allocate_cluster_based_subsector(subsector, year, meta, plant_allocated_mask, plant_data_list,
                                               master_withdrawal, master_consumption, detailed_country_data)
    
    # Original logic for other sectors
    debug_log(f"Allocating {subsector} {year}", "INFO")
    
    totals_by_country = {'withdrawal': defaultdict(float), 'consumption': defaultdict(float)}
    
    if subsector not in MODEL_DATA_CACHE:
        debug_log(f"No model data for {subsector}", "WARNING")
        return totals_by_country
    
    df = MODEL_DATA_CACHE[subsector]
    countries = [col for col in df.columns if col.lower() != "year"]
    
    if subsector == "Food_Bev":
        withdrawal_constants = FOOD_BEV_WITHDRAWAL_CONSTANTS
        consumption_constants = FOOD_BEV_CONSUMPTION_CONSTANTS
    else:
        withdrawal_constants = SUBSECTOR_WITHDRAWAL_CONSTANTS
        consumption_constants = SUBSECTOR_CONSUMPTION_CONSTANTS
    
    transform = meta["transform"]
    
    for country in countries:
        if year not in df["Year"].values:
            continue
            
        year_data = df[df["Year"] == year]
        if year_data.empty:
            continue
        
        production = year_data[country].iloc[0]
        if pd.isna(production) or production == 0:
            continue
        
        if subsector in NO_WWI_MULTIPLIER_SECTORS:
            water_multiplier = 1.0
        else:
            water_multiplier = get_water_multiplier(country, year)
        
        if subsector == "Food_Bev":
            withdrawal_const = withdrawal_constants.get(country, 1.0)
            consumption_const = consumption_constants.get(country, 1.0)
        else:
            withdrawal_const = withdrawal_constants.get(subsector, 1.0)
            consumption_const = consumption_constants.get(subsector, 1.0)
        
        total_withdrawal = production * withdrawal_const * water_multiplier
        total_consumption = production * consumption_const * water_multiplier
        
        if total_withdrawal == 0 and total_consumption == 0:
            continue
        
        if subsector not in detailed_country_data:
            detailed_country_data[subsector] = {}
        detailed_country_data[subsector][country] = {'production': production}
        
        # Plant-based allocation for non-Mining sectors
        key = f"{subsector}_{country}"
        has_plants = key in PLANT_DATA_CACHE
        
        if not has_plants:
            for stored_key in PLANT_DATA_CACHE:
                if stored_key.lower() == key.lower():
                    key = stored_key
                    has_plants = True
                    break
        
        allocated = False
        
        if has_plants:
            capacities, total_cap = get_plant_capacities(subsector, country, year)
            
            if total_cap > 0:
                debug_log(f"Found {len(capacities)} plants for {country} with total capacity {total_cap}", "DEBUG")
                
                for plant_col, capacity in capacities.items():
                    if capacity > 0:
                        ratio = capacity / total_cap
                        plant_withdrawal = total_withdrawal * ratio
                        plant_consumption = total_consumption * ratio
                        
                        coord = parse_coord_from_colname(plant_col)
                        if coord and plant_withdrawal > 0:
                            col_idx = int(round((coord[0] - transform[2]) / transform[0]))
                            row_idx = int(round((coord[1] - transform[5]) / transform[4]))
                            
                            add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                          plant_withdrawal, plant_consumption, plant_allocated_mask,
                                          country, subsector, year, transform, plant_data_list, "Freshwater")

                            # Sea-water cooling at the plant's own location (coastal plants only)
                            add_sea_cooling(detailed_country_data, subsector, country, year,
                                            coord[0], coord[1], production * ratio, transform)

                            totals_by_country['withdrawal'][country] += plant_withdrawal
                            totals_by_country['consumption'][country] += plant_consumption
                            allocated = True
        
        if not allocated:
            # Use industrial area center as fallback
            mask_path = None
            for ext in [".tif", ".tiff"]:
                path = os.path.join(OTHERS_FOLDER, f"{country}{ext}")
                if os.path.exists(path):
                    mask_path = path
                    break
            
            if mask_path:
                try:
                    # No plant locations: spread over the country's industrial-area clusters
                    # (same method as Mining / Other), proportional to cluster size.
                    centroids, sizes = get_cluster_centers(mask_path)
                    if centroids:
                        total_cells = float(sum(sizes))
                        for centroid, cell_count in zip(centroids, sizes):
                            prop = cell_count / total_cells
                            col_idx = int(round((centroid[0] - transform[2]) / transform[0]))
                            row_idx = int(round((centroid[1] - transform[5]) / transform[4]))
                            add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                          total_withdrawal * prop, total_consumption * prop,
                                          plant_allocated_mask, country, subsector, year, transform,
                                          plant_data_list, "Freshwater")
                            add_sea_cooling(detailed_country_data, subsector, country, year,
                                            centroid[0], centroid[1], production * prop, transform)
                        totals_by_country['withdrawal'][country] += total_withdrawal
                        totals_by_country['consumption'][country] += total_consumption
                        allocated = True
                        debug_log(f"Used {len(centroids)} industrial-area clusters for {country} {subsector}", "DEBUG")
                    else:
                        with rasterio.open(mask_path) as src:
                            bounds = src.bounds
                            center_lon = (bounds.left + bounds.right) / 2
                            center_lat = (bounds.bottom + bounds.top) / 2
                            col_idx = int(round((center_lon - transform[2]) / transform[0]))
                            row_idx = int(round((center_lat - transform[5]) / transform[4]))
                            add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                          total_withdrawal, total_consumption, plant_allocated_mask,
                                          country, subsector, year, transform, plant_data_list, "Freshwater")
                            add_sea_cooling(detailed_country_data, subsector, country, year,
                                            center_lon, center_lat, production, transform)
                            totals_by_country['withdrawal'][country] += total_withdrawal
                            totals_by_country['consumption'][country] += total_consumption
                            allocated = True
                            debug_log(f"No clusters; used industrial-area centre for {country} {subsector}", "DEBUG")
                except Exception as e:
                    debug_log(f"Error with industrial area for {country}: {e}", "ERROR")
        
        if allocated:
            debug_log(f"SUCCESS: {subsector} {country}: {totals_by_country['withdrawal'][country]:.2f} withdrawal", "INFO")
        else:
            debug_log(f"FAILED: {subsector} {country} - no allocation method worked", "WARNING")
    
    return totals_by_country


# -----------------------------
# VISUALIZATION
# -----------------------------
# Better colors for industrial sectors (more vibrant)
SUBSECTOR_COLORS = {
    "Power_Generation": '#FF0000',     # Bright Red
    "Petro_Ref": '#00AA00',            # Green
    "PetroChem": '#FFD700',            # Gold
    "Steel": '#1E88E5',                # Blue
    "Aluminium": '#FF8C00',            # Dark Orange
    "Cement": '#9C27B0',               # Purple
    "Paper_Pulp": '#00BCD4',           # Cyan
    "Food_Bev": '#E91E63',             # Pink
    "Oil_Extraction": '#8D6E63',       # Brown
    "Mining": '#FF5722',               # Deep Orange
    "Potash": '#673AB7',               # Deep Purple
    "Other": '#757575',                # Gray
}


@lru_cache(maxsize=None)
def get_cluster_centers(mask_path):   # cached: the TIFF never changes during a run
    """Extract clusters of 1s from TIFF and return centroids and cell counts"""
    try:
        with rasterio.open(mask_path) as src:
            mask = src.read(1).astype(np.uint8)
            # Ensure binary mask
            mask = (mask > 0).astype(np.uint8)
            
            # Label connected components (8-connectivity)
            labeled_mask, num_features = ndimage.label(mask, structure=np.ones((3,3)))
            
            if num_features == 0:
                return [], []
            
            # Get centroids and sizes
            centroids = []
            sizes = []
            
            for label_id in range(1, num_features + 1):
                # Get coordinates of this cluster
                cluster_coords = np.where(labeled_mask == label_id)
                if len(cluster_coords[0]) > 0:
                    # Centroid (mean of coordinates)
                    center_row = np.mean(cluster_coords[0])
                    center_col = np.mean(cluster_coords[1])
                    
                    # Convert to geographic coordinates
                    transform = src.transform
                    lon = transform[2] + center_col * transform[0]
                    lat = transform[5] + center_row * transform[4]
                    
                    centroids.append((lon, lat))
                    sizes.append(len(cluster_coords[0]))  # number of cells in cluster
            
            return centroids, sizes
    except Exception as e:
        debug_log(f"Error extracting clusters: {e}", "ERROR")
        return [], []

def allocate_cluster_based_subsector(subsector, year, meta, plant_allocated_mask, plant_data_list,
                                      master_withdrawal, master_consumption, detailed_country_data):
    """Allocate water to multiple clusters within a TIFF (for Mining, Other, etc.)"""
    
    debug_log(f"Allocating {subsector} {year} (cluster-based)", "INFO")
    
    totals_by_country = {'withdrawal': defaultdict(float), 'consumption': defaultdict(float)}
    
    if subsector not in MODEL_DATA_CACHE:
        debug_log(f"No model data for {subsector}", "WARNING")
        return totals_by_country
    
    df = MODEL_DATA_CACHE[subsector]
    countries = [col for col in df.columns if col.lower() != "year"]
    
    if subsector == "Food_Bev":
        withdrawal_constants = FOOD_BEV_WITHDRAWAL_CONSTANTS
        consumption_constants = FOOD_BEV_CONSUMPTION_CONSTANTS
    else:
        withdrawal_constants = SUBSECTOR_WITHDRAWAL_CONSTANTS
        consumption_constants = SUBSECTOR_CONSUMPTION_CONSTANTS
    
    transform = meta["transform"]
    
    for country in countries:
        if year not in df["Year"].values:
            continue
            
        year_data = df[df["Year"] == year]
        if year_data.empty:
            continue
        
        production = year_data[country].iloc[0]
        if pd.isna(production) or production == 0:
            continue
        
        if subsector in NO_WWI_MULTIPLIER_SECTORS:
            water_multiplier = 1.0
        else:
            water_multiplier = get_water_multiplier(country, year)
        
        if subsector == "Food_Bev":
            withdrawal_const = withdrawal_constants.get(country, 1.0)
            consumption_const = consumption_constants.get(country, 1.0)
        else:
            withdrawal_const = withdrawal_constants.get(subsector, 1.0)
            consumption_const = consumption_constants.get(subsector, 1.0)
        
        total_withdrawal = production * withdrawal_const * water_multiplier
        total_consumption = production * consumption_const * water_multiplier
        
        if total_withdrawal == 0 and total_consumption == 0:
            continue
        
        # Store production for sea water cooling
        if subsector not in detailed_country_data:
            detailed_country_data[subsector] = {}
        detailed_country_data[subsector][country] = {'production': production}
        
        # Get TIFF path for this country/subsector
        mask_path = None
        
        if subsector == "Mining":
            mining_tif_path = os.path.join(ROOT, "Mining", "Mining_tif", f"{country}.tif")
            if os.path.exists(mining_tif_path):
                mask_path = mining_tif_path
            else:
                industrial_fallback = os.path.join(OTHERS_FOLDER, f"{country}.tif")
                if os.path.exists(industrial_fallback):
                    mask_path = industrial_fallback
        else:
            # Other sectors use industrial area TIFF
            for ext in [".tif", ".tiff"]:
                path = os.path.join(OTHERS_FOLDER, f"{country}{ext}")
                if os.path.exists(path):
                    mask_path = path
                    break
        
        if mask_path:
            # Get clusters
            centroids, sizes = get_cluster_centers(mask_path)
            
            if centroids:
                total_cells = sum(sizes)
                debug_log(f"{subsector} {country}: Found {len(centroids)} clusters with {total_cells} total cells", "INFO")
                
                # Allocate water proportionally to cluster size (by cell count)
                for idx, (centroid, cell_count) in enumerate(zip(centroids, sizes)):
                    # Proportion based on cell count
                    proportion = cell_count / total_cells
                    cluster_withdrawal = total_withdrawal * proportion
                    cluster_consumption = total_consumption * proportion
                    
                    # Convert centroid to raster coordinates
                    col_idx = int(round((centroid[0] - transform[2]) / transform[0]))
                    row_idx = int(round((centroid[1] - transform[5]) / transform[4]))
                    
                    water_type = "Freshwater"
                    if subsector == "Mining":
                        water_type = "Mining"
                    
                    add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                  cluster_withdrawal, cluster_consumption, plant_allocated_mask,
                                  country, subsector, year, transform, plant_data_list, water_type)
                    
                    totals_by_country['withdrawal'][country] += cluster_withdrawal
                    totals_by_country['consumption'][country] += cluster_consumption
                    
                    debug_log(f"  Cluster {idx+1}: {cell_count} cells, {cluster_withdrawal:.2f} withdrawal", "DEBUG")
            else:
                # Fallback to single center point
                debug_log(f"No clusters found, using single center for {country}", "WARNING")
                with rasterio.open(mask_path) as src:
                    bounds = src.bounds
                    center_lon = (bounds.left + bounds.right) / 2
                    center_lat = (bounds.bottom + bounds.top) / 2
                    
                    col_idx = int(round((center_lon - transform[2]) / transform[0]))
                    row_idx = int(round((center_lat - transform[5]) / transform[4]))
                    
                    add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                  total_withdrawal, total_consumption, plant_allocated_mask,
                                  country, subsector, year, transform, plant_data_list, "Freshwater")
                    
                    totals_by_country['withdrawal'][country] += total_withdrawal
                    totals_by_country['consumption'][country] += total_consumption
        else:
            debug_log(f"No TIFF found for {country} {subsector}", "WARNING")
    
    return totals_by_country

def draw_basemap(ax, meta):
    """Natural Earth basemap: sea, land, coastline, country borders. No place labels."""
    ne = load_natural_earth()
    left, right, bottom, top = calculate_extent(meta)
    ax.set_facecolor('#CFE6F5')
    ne["land"].plot(ax=ax, facecolor='#F2EFE6', edgecolor='#555555', linewidth=0.6, zorder=0)
    ne["countries"].boundary.plot(ax=ax, color='#8C8C8C', linewidth=0.6, linestyle='--', zorder=1)
    ax.set_xlim(left, right)
    ax.set_ylim(bottom, top)
    ax.set_aspect('equal')
    ax.tick_params(labelsize=11)

def add_size_legend(ax, size_func, extra_legend=None, values=(1, 10, 100)):
    """Proportional-circle key inside the map, bottom-right, on a white panel:
    title on top, circles in a row (same marker area as the plot), value under each circle."""
    if extra_legend is not None:
        ax.add_artist(extra_legend)
    key = ax.inset_axes([0.822, 0.015, 0.163, 0.088])
    key.set_zorder(20000)
    key.set_facecolor((1, 1, 1, 0.93))
    for sp in key.spines.values():
        sp.set_edgecolor('#9E9E9E')
        sp.set_linewidth(0.9)
    key.set_xticks([])
    key.set_yticks([])
    key.set_xlim(0, 1)
    key.set_ylim(0, 1)
    xs = np.linspace(0.2, 0.8, len(values))
    for x, v in zip(xs, values):
        key.scatter([x], [0.47], s=float(size_func(v)), c='#BDBDBD', edgecolors='#424242',
                    linewidths=1.2, clip_on=False)
        key.text(x, 0.03, f"{v:g}", ha='center', va='bottom', fontsize=14)
    key.text(0.5, 0.97, "Withdrawal (Mm\u00b3 yr\u207b\u00b9)", ha='center', va='top', fontsize=14)

def create_visualizations(year, meta, plant_data_list):
    """Create visualizations with sector-specific scaling and dual legends"""
    if not CREATE_VISUALIZATIONS:
        debug_log("Visualizations disabled (CREATE_VISUALIZATIONS=False)", "WARNING")
        return
    
    global POWER_RANGE, INDUSTRIAL_RANGE
    
    debug_log(f"=== STARTING VISUALIZATIONS FOR YEAR {year} ===", "INFO")
    debug_log(f"Number of plants: {len(plant_data_list)}", "INFO")
    
    # Check if ranges are calculated
    if POWER_RANGE is None or INDUSTRIAL_RANGE is None:
        debug_log(f"ERROR: Ranges not calculated! POWER_RANGE={POWER_RANGE}, INDUSTRIAL_RANGE={INDUSTRIAL_RANGE}", "ERROR")
        return
    
    debug_log(f"POWER_RANGE: {POWER_RANGE}", "INFO")
    debug_log(f"INDUSTRIAL_RANGE: {INDUSTRIAL_RANGE}", "INFO")
    
    # Check if there are any plants
    if not plant_data_list:
        debug_log("No plants to visualize", "WARNING")
        return
    
    # Sector-specific circle size functions
    def get_circle_size_power(withdrawal):
        min_size, max_size = 250, 2000
        max_ref = 200

        log_min = np.log10(1)
        log_max = np.log10(max_ref)
        log_val = np.log10(max(withdrawal, 1))

        normalized = (log_val - log_min) / (log_max - log_min)
        normalized = np.clip(normalized, 0, 1)

        size = min_size + (max_size - min_size) * normalized
        return np.clip(size, min_size, max_size)
    
    def get_circle_size_industrial(withdrawal):
        min_size, max_size = 250, 2000
        max_ref = 200

        log_min = np.log10(1)
        log_max = np.log10(max_ref)
        log_val = np.log10(max(withdrawal, 1))

        normalized = (log_val - log_min) / (log_max - log_min)
        normalized = np.clip(normalized, 0, 1)

        size = min_size + (max_size - min_size) * normalized
        return np.clip(size, min_size, max_size)
    
    # Sort plants by withdrawal (smallest first for layering)
    plant_data_list_sorted = sorted(plant_data_list, key=lambda x: x['withdrawal'])
    
    # Separate power generation from industrial
    power_plants = [p for p in plant_data_list_sorted if p['subsector'] == "Power_Generation"]
    industrial_plants = [p for p in plant_data_list_sorted if p['subsector'] != "Power_Generation"]
    
    debug_log(f"Power plants: {len(power_plants)}, Industrial plants: {len(industrial_plants)}", "INFO")

    # High contrast color palette
    SUBSECTOR_COLORS_PRO = {
        "Power_Generation": '#E6194B',     # Bright Red
        "Petro_Ref": '#3B75AF',            # Medium Blue
        "PetroChem": '#F58220',            # Orange
        "Steel": '#3CB44B',               # Green
        "Aluminium": '#911EB4',           # Purple
        "Cement": '#F032E6',              # Magenta
        "Paper_Pulp": '#46F0F0',          # Cyan
        "Food_Bev": '#008080',            # Teal
        "Oil_Extraction": '#E6BEFF',      # Lavender
        "Mining": '#FFD700',              # Gold/Yellow
        "Potash": '#FF6EB4',              # Hot Pink
        "Other": '#808080',               # Gray
    }
    
    # Scientific naming
    SECTOR_SCIENTIFIC_NAMES = {
        "Power_Generation": "Power Generation",
        "Petro_Ref": "Petroleum Refining",
        "PetroChem": "Petrochemicals",
        "Steel": "Steel Manufacturing",
        "Aluminium": "Aluminium Production",
        "Cement": "Cement Production",
        "Paper_Pulp": "Paper & Pulp",
        "Food_Bev": "Food & Beverage",
        "Oil_Extraction": "Oil Extraction",
        "Mining": "Mining Operations",
        "Potash": "Potash Mining",
        "Other": "Other Industries",
    }
    
    # ============================================================
    # PLOT 1: Power Generation Only (separate)
    # ============================================================
    if power_plants:
        try:
            debug_log("Creating Power Generation plot...", "INFO")
            fig1, ax1 = plt.subplots(figsize=(24, 18))
            
            draw_basemap(ax1, meta)
            
            cooling_colors = {
                'Power_Sea': '#1E88E5',
                'Power_Fresh': '#E53935',
                'Power_Reused': '#E53935',
                'Power_Dry': '#757575',
                'Power_Renewable': '#43A047'
            }
            
            cooling_scientific_names = {
                'Power_Sea': 'Sea Water Cooling',
                'Power_Fresh': 'Fresh Water Cooling',
                'Power_Reused': 'Fresh Water Cooling (Reused)',
                'Power_Dry': 'Dry Cooling',
                'Power_Renewable': 'Renewable Energy'
            }
            
            power_by_cooling = defaultdict(list)
            for plant in power_plants:
                cooling_type = plant.get('water_type', 'Power_Fresh')
                if cooling_type == 'Power_Reused':
                    cooling_type = 'Power_Fresh'
                power_by_cooling[cooling_type].append(plant)
            
            for cooling_type, plants in power_by_cooling.items():
                color = cooling_colors.get(cooling_type, '#E53935')
                for plant in plants:
                    size = get_circle_size_power(plant['withdrawal'])
                    zorder = 10000 - size
                    ax1.scatter(plant['lon'], plant['lat'], s=size, c=color, 
                               alpha=0.75, edgecolors='white', linewidth=2, zorder=zorder)
            
            legend_handles = []
            for cooling_type, plants in power_by_cooling.items():
                display_name = cooling_scientific_names.get(cooling_type, cooling_type.replace('Power_', ''))
                legend_handles.append(plt.Line2D([0], [0], marker='o', color='w',
                                   markerfacecolor=cooling_colors.get(cooling_type, '#E53935'), 
                                   markersize=12, label=display_name))
            
            leg1 = ax1.legend(handles=legend_handles, loc='upper right', framealpha=0.95, 
                      fontsize=12, handlelength=2, handleheight=2, borderaxespad=1,
                      title="Cooling Technology", title_fontsize=14)
            ax1.set_xlabel('Longitude', fontsize=14, fontweight='semibold')
            ax1.set_ylabel('Latitude', fontsize=14, fontweight='semibold')
            ax1.set_title(f'Power Generation: Water Withdrawal ({year})', fontsize=16, fontweight='bold', pad=12)
            add_size_legend(ax1, get_circle_size_power, extra_legend=leg1)
            
            output_path = os.path.join(OUT_PNG, f"power_generation_{year}.png")
            debug_log(f"Saving to: {output_path}", "INFO")
            plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
            plt.close(fig1)
            
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path)
                debug_log(f"Power generation plot saved successfully: {output_path} ({file_size} bytes)", "INFO")
            else:
                debug_log(f"ERROR: File was not created at {output_path}", "ERROR")
                
        except Exception as e:
            debug_log(f"Error creating power generation plot: {e}", "ERROR")
            import traceback
            traceback.print_exc()
    else:
        debug_log("No power plants to plot", "INFO")
    
    # ============================================================
    # PLOT 2: Industrial Sectors Only (separate scaling)
    # ============================================================
    if industrial_plants:
        try:
            debug_log("Creating Industrial sectors plot...", "INFO")
            fig2, ax2 = plt.subplots(figsize=(24, 18))
            
            draw_basemap(ax2, meta)
            
            for subsector in SUBSECTOR_COLORS_PRO.keys():
                if subsector == "Power_Generation":
                    continue
                
                sector_plants = [p for p in industrial_plants if p['subsector'] == subsector]
                if not sector_plants:
                    continue
                
                color = SUBSECTOR_COLORS_PRO[subsector]
                
                for plant in sector_plants:
                    size = get_circle_size_industrial(plant['withdrawal'])
                    zorder = 10000 - size
                    ax2.scatter(plant['lon'], plant['lat'], s=size, c=color, 
                               alpha=0.75, edgecolors='white', linewidth=2, zorder=zorder)
            
            legend_handles = []
            for subsector, color in SUBSECTOR_COLORS_PRO.items():
                if subsector == "Power_Generation":
                    continue
                if any(p['subsector'] == subsector for p in industrial_plants):
                    scientific_name = SECTOR_SCIENTIFIC_NAMES.get(subsector, subsector)
                    legend_handles.append(plt.Line2D([0], [0], marker='o', color='w',
                                       markerfacecolor=color, markersize=12, 
                                       label=scientific_name))
            
            leg2 = ax2.legend(handles=legend_handles, loc='upper right', framealpha=0.95, 
                      fontsize=11, handlelength=2, handleheight=2, borderaxespad=1,
                      title="Industrial Sector", title_fontsize=14, 
                      ncol=2 if len(legend_handles) > 8 else 1)
            ax2.set_xlabel('Longitude', fontsize=14, fontweight='semibold')
            ax2.set_ylabel('Latitude', fontsize=14, fontweight='semibold')
            ax2.set_title(f'Industrial Sectors: Water Withdrawal ({year})', fontsize=16, fontweight='bold', pad=12)
            add_size_legend(ax2, get_circle_size_industrial, extra_legend=leg2)
            
            output_path = os.path.join(OUT_PNG, f"industrial_sectors_{year}.png")
            debug_log(f"Saving to: {output_path}", "INFO")
            plt.savefig(output_path, dpi=150, bbox_inches='tight', facecolor='white')
            plt.close(fig2)
            
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path)
                debug_log(f"Industrial sectors plot saved successfully: {output_path} ({file_size} bytes)", "INFO")
            else:
                debug_log(f"ERROR: File was not created at {output_path}", "ERROR")
                
        except Exception as e:
            debug_log(f"Error creating industrial sectors plot: {e}", "ERROR")
            import traceback
            traceback.print_exc()
    else:
        debug_log("No industrial plants to plot", "INFO")
    
        # ============================================================
    # PLOT 3: Combined (TWO LEGEND GROUPS - industrial 2 cols, power 2 cols)
    # ============================================================
    if power_plants or industrial_plants:
        try:
            debug_log("Creating Combined plot...", "INFO")
            fig3, ax3 = plt.subplots(figsize=(24, 18))
            
            draw_basemap(ax3, meta)
            
            # Get industrial sectors that actually have plants
            industrial_sectors_present = []
            industrial_colors = []
            for subsector, color in SUBSECTOR_COLORS_PRO.items():
                if subsector == "Power_Generation":
                    continue
                sector_plants = [p for p in plant_data_list_sorted if p['subsector'] == subsector]
                if sector_plants:
                    industrial_sectors_present.append(subsector)
                    industrial_colors.append(color)
            
            # Get power cooling types present
            power_cooling_present = []
            power_cooling_colors = []
            if power_plants:
                cooling_types_seen = set()
                for plant in power_plants:
                    cooling_type = plant.get('water_type', 'Power_Fresh')
                    if cooling_type == 'Power_Reused':
                        cooling_type = 'Power_Fresh'
                    if cooling_type not in cooling_types_seen:
                        cooling_types_seen.add(cooling_type)
                        power_cooling_present.append(cooling_type)
                        cooling_colors = {
                            'Power_Sea': '#1E88E5',
                            'Power_Fresh': '#E53935',
                            'Power_Dry': '#757575',
                            'Power_Renewable': '#43A047'
                        }
                        power_cooling_colors.append(cooling_colors.get(cooling_type, '#E53935'))
            
            # Create first legend for industrial sectors (2 columns)
            if industrial_sectors_present:
                industrial_handles = []
                for i, subsector in enumerate(industrial_sectors_present):
                    scientific_name = SECTOR_SCIENTIFIC_NAMES.get(subsector, subsector)
                    industrial_handles.append(plt.Line2D([0], [0], marker='o', color='w',
                                               markerfacecolor=industrial_colors[i], markersize=14, 
                                               label=scientific_name))
                
                # Plot industrial sectors
                for subsector, color in zip(industrial_sectors_present, industrial_colors):
                    sector_plants = [p for p in plant_data_list_sorted if p['subsector'] == subsector]
                    for plant in sector_plants:
                        size = get_circle_size_industrial(plant['withdrawal'])
                        zorder = 10000 - size
                        ax3.scatter(plant['lon'], plant['lat'], s=size, c=color, 
                                   alpha=0.75, edgecolors='white', linewidth=2, zorder=zorder)
                
                # Add first legend
                legend1 = ax3.legend(handles=industrial_handles, loc='upper right', framealpha=0.95, 
                                    fontsize=15, handlelength=2, handleheight=2, borderaxespad=1,
                                    title="Industrial Sectors", title_fontsize=18,
                                    ncol=2)
                ax3.add_artist(legend1)
            
            # Create second legend for power generation (2 columns)
            if power_cooling_present:
                cooling_scientific_names = {
                    'Power_Sea': 'Sea Water Cooling',
                    'Power_Fresh': 'Fresh Water Cooling',
                    'Power_Dry': 'Dry Cooling',
                    'Power_Renewable': 'Renewable Energy'
                }
                
                power_handles = []
                for i, cooling_type in enumerate(power_cooling_present):
                    display_name = cooling_scientific_names.get(cooling_type, cooling_type.replace('Power_', ''))
                    power_handles.append(plt.Line2D([0], [0], marker='o', color='w',
                                          markerfacecolor=power_cooling_colors[i], markersize=14, 
                                          label=display_name))
                
                # Plot power plants
                for cooling_type in power_cooling_present:
                    cooling_colors = {
                        'Power_Sea': '#1E88E5',
                        'Power_Fresh': '#E53935',
                        'Power_Dry': '#757575',
                        'Power_Renewable': '#43A047'
                    }
                    color = cooling_colors.get(cooling_type, '#E53935')
                    # Get plants of this cooling type (including Reused mapped to Fresh)
                    plants_of_type = []
                    for plant in power_plants:
                        plant_type = plant.get('water_type', 'Power_Fresh')
                        if plant_type == 'Power_Reused':
                            plant_type = 'Power_Fresh'
                        if plant_type == cooling_type:
                            plants_of_type.append(plant)
                    
                    for plant in plants_of_type:
                        size = get_circle_size_power(plant['withdrawal'])
                        zorder = 10000 - size
                        ax3.scatter(plant['lon'], plant['lat'], s=size, c=color, 
                                   alpha=0.75, edgecolors='white', linewidth=2, zorder=zorder)
                


                fig3.canvas.draw()
                bbox1 = legend1.get_window_extent(fig3.canvas.get_renderer()).transformed(ax3.transAxes.inverted())

                x_center = (bbox1.x0 + bbox1.x1) / 2 - 0.01

                legend2 = ax3.legend(
                    handles=power_handles,
                    loc='upper left',
                    bbox_to_anchor=(bbox1.x0, bbox1.y0 - 0.004, bbox1.width, 0),
                    mode="expand",
                    borderaxespad=0,
                    framealpha=0.95,
                    fontsize=15,
                    title="Power Generation Cooling Types",
                    title_fontsize=18,
                    ncol=2
                )
                ax3.add_artist(legend2)
                legend1.set_zorder(30000)
                legend2.set_zorder(30000)
            
            add_size_legend(ax3, get_circle_size_industrial, extra_legend=None)
            ax3.set_xlabel('Longitude', fontsize=14, fontweight='semibold')
            ax3.set_ylabel('Latitude', fontsize=14, fontweight='semibold')
            
            
            output_path = os.path.join(OUT_PNG, f"all_sectors_{year}.png")
            debug_log(f"Saving to: {output_path}", "INFO")
            plt.savefig(output_path, dpi=900, bbox_inches='tight', facecolor='white')
            plt.close(fig3)
            
            if os.path.exists(output_path):
                file_size = os.path.getsize(output_path)
                debug_log(f"Combined plot saved successfully: {output_path} ({file_size} bytes)", "INFO")
            else:
                debug_log(f"ERROR: File was not created at {output_path}", "ERROR")
                
        except Exception as e:
            debug_log(f"Error creating combined plot: {e}", "ERROR")
            import traceback
            traceback.print_exc()
    else:
        debug_log("No plants at all to plot", "INFO")
    
    debug_log(f"=== FINISHED VISUALIZATIONS FOR YEAR {year} ===", "INFO")

def calculate_extent(meta):
    transform = meta['transform']
    left = transform[2]
    top = transform[5]
    right = left + transform[0] * meta['width']
    bottom = top + transform[4] * meta['height']
    return [left, right, bottom, top]

# -----------------------------
# EXCEL OUTPUT - ONE ROW PER PLANT
# -----------------------------
def write_excel_output(year, plant_data_list, detailed_country_data):
    """Write Excel - one row per plant"""
    
    debug_log(f"Writing Excel output for {year}", "INFO")
    
    rows = []
    
    # Add plants
    for plant in plant_data_list:
        rows.append({
            'Year': plant['year'],
            'Subsector': plant['subsector'],
            'Country': plant['country'],
            'X': plant['lon'],
            'Y': plant['lat'],
            'WaterType': plant['water_type'],
            'Withdrawal_m3': plant['withdrawal'],
            'Consumption_m3': plant['consumption'],
            'DistToCoast_km': np.nan
        })

    # Sea water cooling: one row per COASTAL plant, at the plant's own x, y
    for subsector in SEA_WATER_COOLING_RATES_WITHDRAWAL.keys():
        for country, values in detailed_country_data.get(subsector, {}).items():
            for sp in values.get('sea_plants', []):
                rows.append({
                    'Year': year,
                    'Subsector': subsector,
                    'Country': country,
                    'X': sp['lon'],
                    'Y': sp['lat'],
                    'WaterType': 'SeaWater_Cooling',
                    'Withdrawal_m3': sp['withdrawal'],
                    'Consumption_m3': sp['consumption'],
                    'DistToCoast_km': sp['dist_km']
                })
            n_chk, n_sea = values.get('plants_checked', 0), len(values.get('sea_plants', []))
            if n_chk:
                debug_log(f"Sea cooling {subsector} {country} {year}: {n_sea}/{n_chk} plants within "
                          f"{COAST_DISTANCE_KM:.0f} km of coast", "INFO")
    
    df = pd.DataFrame(rows)
    output_file = os.path.join(DETAILED_OUTPUT_DIR, f"water_allocation_{year}.xlsx")
    df.to_excel(output_file, index=False)
    
    debug_log(f"Saved {len(rows)} rows to {output_file}", "INFO")
    debug_log(f"Total withdrawal: {df['Withdrawal_m3'].sum():.2f} m³", "INFO")
    debug_log(f"Total consumption: {df['Consumption_m3'].sum():.2f} m³", "INFO")
    
    # Summary by subsector
    summary = df.groupby('Subsector').agg({
        'Withdrawal_m3': 'sum',
        'Consumption_m3': 'sum'
    }).reset_index()
    
    summary_file = os.path.join(DETAILED_OUTPUT_DIR, f"summary_{year}.xlsx")
    summary.to_excel(summary_file, index=False)
    
    return df

# -----------------------------
# MAIN PROCESSING
# -----------------------------
def process_year(year, meta):
    """Process one year - simple and straightforward"""
    
    debug_log(f"{'='*50}", "INFO")
    debug_log(f"PROCESSING YEAR {year}", "INFO")
    debug_log(f"{'='*50}", "INFO")
    
    # Initialize
    template_arr = np.zeros((meta["height"], meta["width"]), dtype=np.float32)
    master_withdrawal = np.zeros_like(template_arr, dtype=np.float32)
    master_consumption = np.zeros_like(template_arr, dtype=np.float32)
    plant_allocated_mask = np.zeros_like(template_arr, dtype=bool)
    plant_data_list = []
    detailed_country_data = {}
    transform = meta["transform"]  # Make sure transform is defined
    
    # 1. Power Generation
    power_totals = allocate_power_generation(year, meta, plant_allocated_mask, plant_data_list,
                                             master_withdrawal, master_consumption)
    
    # 2. Industrial sectors (excluding Power and Other)
    for subsector in SUBSECTORS:
        if subsector in ["Power_Generation", "Other"]:
            continue
        
        totals = allocate_industrial_subsector(subsector, year, meta, plant_allocated_mask, plant_data_list,
                                               master_withdrawal, master_consumption, detailed_country_data)
    
    # 3. Other sector (5% of non-power sectors) - Use cluster-based allocation
    debug_log(f"Processing Other sector ({OTHER_SECTOR_PERCENTAGE*100}% of non-power)", "INFO")
    
    # Calculate total non-power withdrawal and consumption per country
    non_power_withdrawal = defaultdict(float)
    non_power_consumption = defaultdict(float)
    
    for plant in plant_data_list:
        if plant['subsector'] != "Power_Generation":
            non_power_withdrawal[plant['country']] += plant['withdrawal']
            non_power_consumption[plant['country']] += plant['consumption']
    
    # Calculate Other sector values (5% of non-power)
    other_withdrawal = {country: total * OTHER_SECTOR_PERCENTAGE for country, total in non_power_withdrawal.items()}
    # Other manufacturing: consumption = 0.42 x its own withdrawal
    OTHER_CONSUMPTION_RATIO = 0.42
    other_consumption = {country: w * OTHER_CONSUMPTION_RATIO for country, w in other_withdrawal.items()}
    
    # Use cluster-based allocation for Other sector
    for country, withdrawal in other_withdrawal.items():
        if withdrawal <= 0:
            continue
        
        consumption = other_consumption.get(country, 0)
        
        # Find industrial area TIFF for this country
        mask_path = None
        for ext in [".tif", ".tiff"]:
            path = os.path.join(OTHERS_FOLDER, f"{country}{ext}")
            if os.path.exists(path):
                mask_path = path
                break
        
        if mask_path:
            # Get clusters
            centroids, sizes = get_cluster_centers(mask_path)
            
            if centroids:
                total_cells = sum(sizes)
                debug_log(f"Other {country}: Found {len(centroids)} clusters with {total_cells} total cells", "INFO")
                
                for idx, (centroid, cell_count) in enumerate(zip(centroids, sizes)):
                    proportion = cell_count / total_cells
                    cluster_withdrawal = withdrawal * proportion
                    cluster_consumption = consumption * proportion
                    
                    col_idx = int(round((centroid[0] - transform[2]) / transform[0]))
                    row_idx = int(round((centroid[1] - transform[5]) / transform[4]))
                    
                    add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                  cluster_withdrawal, cluster_consumption, plant_allocated_mask,
                                  country, "Other", year, transform, plant_data_list, "Freshwater")
                    
                    debug_log(f"  Other cluster {idx+1}: {cell_count} cells, {cluster_withdrawal:.2f} withdrawal", "DEBUG")
            else:
                # Fallback to single center if no clusters found
                debug_log(f"No clusters found for {country}, using single center", "WARNING")
                with rasterio.open(mask_path) as src:
                    bounds = src.bounds
                    center_lon = (bounds.left + bounds.right) / 2
                    center_lat = (bounds.bottom + bounds.top) / 2
                    
                    col_idx = int(round((center_lon - transform[2]) / transform[0]))
                    row_idx = int(round((center_lat - transform[5]) / transform[4]))
                    
                    add_plant_point(master_withdrawal, master_consumption, row_idx, col_idx,
                                  withdrawal, consumption, plant_allocated_mask,
                                  country, "Other", year, transform, plant_data_list, "Freshwater")
        else:
            debug_log(f"No industrial area TIFF found for {country}, skipping Other sector", "WARNING")
    
    # 4. Write outputs
    write_excel_output(year, plant_data_list, detailed_country_data)
    
    if WRITE_TIF_OUTPUT:
        write_raster(os.path.join(OUT_TIF, f"withdrawal_{year}.tif"), master_withdrawal, meta)
        write_raster(os.path.join(OUT_TIF, f"consumption_{year}.tif"), master_consumption, meta)
    
    create_visualizations(year, meta, plant_data_list)
    
    # Print summary
    total_withdrawal = sum(p['withdrawal'] for p in plant_data_list)
    total_consumption = sum(p['consumption'] for p in plant_data_list)
    
    debug_log(f"{'='*50}", "INFO")
    debug_log(f"YEAR {year} COMPLETE", "INFO")
    debug_log(f"Total plants allocated: {len(plant_data_list)}", "INFO")
    debug_log(f"Total withdrawal: {total_withdrawal:.2f} m³", "INFO")
    debug_log(f"Total consumption: {total_consumption:.2f} m³", "INFO")
    debug_log(f"{'='*50}", "INFO")
    
    return master_withdrawal, master_consumption, plant_data_list

# -----------------------------
# GLOBAL RANGE CALCULATION
# -----------------------------
POWER_RANGE = None
INDUSTRIAL_RANGE = None

def calculate_global_ranges(years, meta):
    """Calculate global min/max for power and industrial sectors across all years"""
    global POWER_RANGE, INDUSTRIAL_RANGE
    
    debug_log("Calculating global ranges across all years...", "INFO")
    
    power_withdrawals = []
    industrial_withdrawals = []
    
    for year in years:
        debug_log(f"Scanning year {year} for range calculation...", "DEBUG")
        
        # Quick collection of withdrawals
        template_arr = np.zeros((meta["height"], meta["width"]), dtype=np.float32)
        master_withdrawal = np.zeros_like(template_arr, dtype=np.float32)
        master_consumption = np.zeros_like(template_arr, dtype=np.float32)
        plant_allocated_mask = np.zeros_like(template_arr, dtype=bool)
        plant_data_list_temp = []
        detailed_country_data_temp = {}
        
        # Process power
        power_totals = allocate_power_generation(year, meta, plant_allocated_mask, plant_data_list_temp,
                                                 master_withdrawal, master_consumption)
        
        # Process industrial (excluding Power and Other)
        for subsector in SUBSECTORS:
            if subsector in ["Power_Generation", "Other"]:
                continue
            totals = allocate_industrial_subsector(subsector, year, meta, plant_allocated_mask, plant_data_list_temp,
                                                   master_withdrawal, master_consumption, detailed_country_data_temp)
        
        # Separate withdrawals by type
        for plant in plant_data_list_temp:
            if plant['withdrawal'] > 0:
                if plant['subsector'] == "Power_Generation":
                    power_withdrawals.append(plant['withdrawal'])
                else:
                    industrial_withdrawals.append(plant['withdrawal'])
    
    # Calculate ranges using percentiles to avoid outliers
    if power_withdrawals:
        # Use 5th and 95th percentiles
        POWER_RANGE = (np.percentile(power_withdrawals, 5), np.percentile(power_withdrawals, 95))
        debug_log(f"Power sector range (5th-95th percentile): {POWER_RANGE[0]:.2f} - {POWER_RANGE[1]:.2f} m³", "INFO")
    else:
        POWER_RANGE = (1, 1)
        debug_log("No power plants found", "WARNING")
    
    if industrial_withdrawals:
        INDUSTRIAL_RANGE = (np.percentile(industrial_withdrawals, 5), np.percentile(industrial_withdrawals, 95))
        debug_log(f"Industrial sector range (5th-95th percentile): {INDUSTRIAL_RANGE[0]:.2f} - {INDUSTRIAL_RANGE[1]:.2f} m³", "INFO")
    else:
        INDUSTRIAL_RANGE = (1, 1)
        debug_log("No industrial plants found", "WARNING")
    
    debug_log("Global ranges calculation complete!", "INFO")

def main():
    global POWER_RANGE, INDUSTRIAL_RANGE
    
    debug_log("=== INDUSTRIAL WATER ALLOCATION ===", "INFO")
    
    # Preload all data
    preload_all_data()
    
    # Read template raster
    meta, _ = read_template_raster(TEMPLATE_TIF)
    
    # Calculate global ranges FIRST before creating visualizations
    calculate_global_ranges(YEARS, meta)
    
    # Verify ranges were calculated
    debug_log(f"Final POWER_RANGE: {POWER_RANGE}", "INFO")
    debug_log(f"Final INDUSTRIAL_RANGE: {INDUSTRIAL_RANGE}", "INFO")
    
    # DEBUG: Check Mining TIFF files
    debug_log("=== CHECKING MINING TIFF FILES ===", "INFO")
    mining_folder = os.path.join(ROOT, "Mining", "Mining_tif")
    if os.path.exists(mining_folder):
        mining_files = glob.glob(os.path.join(mining_folder, "*.tif"))
        debug_log(f"Mining TIFF files found: {mining_files}", "INFO")
        for f in mining_files:
            debug_log(f"  - {os.path.basename(f)}", "INFO")
    else:
        debug_log(f"Mining folder not found: {mining_folder}", "ERROR")
    
    # Check Other folder TIFF files
    debug_log("=== CHECKING OTHER TIFF FILES ===", "INFO")
    if os.path.exists(OTHERS_FOLDER):
        other_files = glob.glob(os.path.join(OTHERS_FOLDER, "*.tif"))
        debug_log(f"Other TIFF files found: {other_files}", "INFO")
        for f in other_files:
            debug_log(f"  - {os.path.basename(f)}", "INFO")
    else:
        debug_log(f"Other folder not found: {OTHERS_FOLDER}", "ERROR")
    
    # Process each year
    for year in YEARS:
        try:
            debug_log(f"Starting processing for year {year}", "INFO")
            process_year(year, meta)
            debug_log(f"Successfully completed year {year}", "INFO")
        except Exception as e:
            debug_log(f"Error processing year {year}: {e}", "ERROR")
            import traceback
            traceback.print_exc()
            continue
    
    debug_log("ALL PROCESSING COMPLETE!", "INFO")

if __name__ == "__main__":
    main()