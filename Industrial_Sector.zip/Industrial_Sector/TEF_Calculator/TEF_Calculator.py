# TEF calculator: observed and predicted water withdrawal intensity (WWI) with uncertainty

# Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from itertools import product
import os
from typing import Dict, List, Tuple, Optional
import warnings
warnings.filterwarnings('ignore')

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


# Configuration
class Config:
    """Settings, input files and countries."""

    # Years
    BASELINE_YEAR = 2020
    START_YEAR = 1990
    END_YEAR = 2025

    # Plotting
    SUBPLOT_ROWS = 2
    SUBPLOT_COLS = 4
    PLOTS_PER_FIGURE = SUBPLOT_ROWS * SUBPLOT_COLS

    # Debug export
    EXPORT_DEBUG = True
    DEBUG_DIR = os.path.join(BASE_DIR, "output")

    # Data file paths
    WATER_FILES = [
        os.path.join(BASE_DIR, "Water", "Industrial_water_aquastat.xlsx")
    ]

    POPULATION_FILES = [
        os.path.join(BASE_DIR, "Population", "Pop_IMF.xlsx"),
        os.path.join(BASE_DIR, "Population", "Pop_WB.xlsx")
    ]

    GDP_FILES = [
        os.path.join(BASE_DIR, "GDP", "GDP_IMF_PPP_2020.xlsx"),
        os.path.join(BASE_DIR, "GDP", "GDP_WB_PPP_2020.xlsx")
    ]

    ENERGY_FILES = [
        os.path.join(BASE_DIR, "Energy_Capita", "Energy_Per_Capita_IEA.xlsx"),
        os.path.join(BASE_DIR, "Energy_Capita", "Energy_Per_Capita_WB.xlsx")
    ]

    ELECTRICITY_FILES = [
        os.path.join(BASE_DIR, "Electricity_Capita", "per_capita_electricity_generation.xlsx")
    ]

    # Countries to analyze
    # Add countries you want to analyze
    COUNTRIES_TO_PLOT = [
        #"Usa", "France","Canada" , "Uk", "Japan","Poland","Chile", "Germany" , "Italy","India","Spain", "Singapore", "South korea", "Mexico","Czech", "Russia", "Netherlands","Sweden", "Norway", "Finland","Austria", "Belgium", "Egypt", "Thailand", "Vietnam","China", "Brazil", "Poland"
        "Jordan","Kuwait","Uae", "Qatar", "Saudi", "Bahrain", "Oman"
    ]


    # Optional: Group countries for separate figures
    COUNTRY_GROUPS = []  # empty: use COUNTRIES_TO_PLOT


# Data loader
class DataLoader:
    """Loads data assuming Year, Country, Value format."""

    @staticmethod
    def load_file(file_path: str, value_col_name: str) -> Optional[pd.DataFrame]:
        """Load a single file and standardize columns."""
        if not os.path.exists(file_path):
            print(f"Warning: File not found: {file_path}")
            return None

        try:
            # Load file
            if file_path.endswith('.xlsx'):
                df = pd.read_excel(file_path)
            elif file_path.endswith('.csv'):
                df = pd.read_csv(file_path)
            else:
                print(f"Unsupported format: {file_path}")
                return None

            # Standardize column names (case-insensitive)
            col_mapping = {}
            for col in df.columns:
                col_lower = str(col).lower()
                if 'year' in col_lower:
                    col_mapping[col] = 'Year'
                elif 'country' in col_lower or 'area' in col_lower or 'region' in col_lower:
                    col_mapping[col] = 'Country'
                else:
                    # Assume this is the value column
                    col_mapping[col] = 'Value'

            df = df.rename(columns=col_mapping)

            # Ensure we have required columns
            if 'Year' not in df.columns or 'Country' not in df.columns or 'Value' not in df.columns:
                print(f"Missing columns in {file_path}")
                return None

            # Clean data
            df['Country'] = df['Country'].astype(str).str.strip().str.title()
            df['Year'] = pd.to_numeric(df['Year'], errors='coerce')
            df['Value'] = pd.to_numeric(df['Value'], errors='coerce')

            # Filter years
            df = df[(df['Year'] >= Config.START_YEAR) & (df['Year'] <= Config.END_YEAR)].copy()

            # Rename value column
            df = df.rename(columns={'Value': value_col_name})

            # Add source info
            df['Source'] = os.path.basename(file_path)

            return df

        except Exception as e:
            print(f"Error loading {file_path}: {e}")
            return None

    @staticmethod
    def load_all_data() -> Dict[str, List[pd.DataFrame]]:
        """Load all parameter files."""
        print("\n" + "="*60)
        print("LOADING ALL DATA FILES")
        print("="*60)

        parameters = {}

        # Define what to load
        to_load = [
            ('water', 'Water', Config.WATER_FILES),
            ('population', 'Population', Config.POPULATION_FILES),
            ('gdp', 'GDP', Config.GDP_FILES),
            ('energy', 'Energy', Config.ENERGY_FILES),
            ('electricity', 'Electricity', Config.ELECTRICITY_FILES),
        ]

        for param_name, value_name, file_list in to_load:
            print(f"\nLoading {param_name.upper()}:")
            param_data = []

            for file_path in file_list:
                df = DataLoader.load_file(file_path, value_name)
                if df is not None and not df.empty:
                    param_data.append(df)
                    print(f"  {os.path.basename(file_path)}: {len(df)} rows")

            if param_data:
                parameters[param_name] = param_data
            else:
                print(f"  No data loaded for {param_name}")

        # Summary
        print("\n" + "="*60)
        print("LOADING SUMMARY")
        print("="*60)
        for param, files in parameters.items():
            total_rows = sum(len(f) for f in files)
            countries = set()
            for f in files:
                countries.update(f['Country'].unique())
            print(f"{param.upper():15s}: {len(files):2d} files, {len(countries):3d} countries, {total_rows:6d} rows")

        return parameters


# Observed WWI calculator
class ObservedCalculator:
    """Calculates observed WWI with uncertainty from multiple files."""

    @staticmethod
    def calculate_observed_wwi(parameters: Dict[str, List[pd.DataFrame]]) -> pd.DataFrame:
        """
        Calculate observed WWI = Water / (Energy * Population)

        NEW LOGIC:
        1. For each Energy × Population combination, calculate WWI_raw for all years
        2. For each combination, normalize ALL years: WWI_norm = WWI_raw / WWI_raw_2020
        3. For each country-year, calculate median and std ACROSS normalized values from all combinations
        """
        print("\n" + "="*60)
        print("CALCULATING OBSERVED WWI")
        print("="*60)

        # Get water data
        water_data = parameters['water'][0].copy() if parameters['water'] else None
        if water_data is None:
            raise ValueError("No water data found")

        # Get all combinations of Energy and Population files
        energy_files = parameters.get('energy', [])
        pop_files = parameters.get('population', [])

        if not energy_files or not pop_files:
            raise ValueError("Need both Energy and Population files")

        print(f"Calculating WWI for {len(energy_files)} energy × {len(pop_files)} population combinations")

        # Store NORMALIZED results for each combination
        all_normalized_results = []

        for i, energy_df in enumerate(energy_files):
            for j, pop_df in enumerate(pop_files):
                # Merge data for this combination
                combo_df = water_data[['Country', 'Year', 'Water']].copy()

                # Merge with energy
                energy_combo = energy_df[['Country', 'Year', 'Energy']].copy()
                combo_df = pd.merge(combo_df, energy_combo, on=['Country', 'Year'], how='inner')

                # Merge with population
                pop_combo = pop_df[['Country', 'Year', 'Population']].copy()
                combo_df = pd.merge(combo_df, pop_combo, on=['Country', 'Year'], how='inner')

                # Skip if no common data
                if combo_df.empty:
                    print(f"  Warning: No common data for energy file {i+1}, population file {j+1}")
                    continue

                # Remove invalid rows
                combo_df = combo_df.dropna(subset=['Water', 'Energy', 'Population'])
                combo_df = combo_df[
                    (combo_df['Water'] > 0) &
                    (combo_df['Energy'] > 0) &
                    (combo_df['Population'] > 0)
                ]

                if combo_df.empty:
                    print(f"  Warning: All data invalid for energy file {i+1}, population file {j+1}")
                    continue

                # Calculate WWI_raw for this combination
                combo_df['WWI_raw'] = combo_df['Water'] / (combo_df['Energy'] * combo_df['Population'])
                combo_df = combo_df[np.isfinite(combo_df['WWI_raw'])]

                if combo_df.empty:
                    print(f"  Warning: All WWI calculations invalid for energy file {i+1}, population file {j+1}")
                    continue

                # Normalise each combination to its own 2020 value
                # For each country in this combination, calculate baseline (2020)
                normalized_dfs = []

                for country in combo_df['Country'].unique():
                    country_df = combo_df[combo_df['Country'] == country].copy()

                    # Get 2020 WWI_raw for this country in THIS combination
                    baseline_2020 = country_df[country_df['Year'] == Config.BASELINE_YEAR]['WWI_raw']

                    if not baseline_2020.empty:
                        wwi_baseline = baseline_2020.values[0]

                        # Normalize ALL years for this country: WWI_norm = WWI_raw / WWI_raw_2020
                        country_df['WWI_norm'] = country_df['WWI_raw'] / wwi_baseline

                        # Store baseline used
                        country_df['WWI_baseline'] = wwi_baseline

                        normalized_dfs.append(country_df)

                if normalized_dfs:
                    normalized_combo = pd.concat(normalized_dfs, ignore_index=True)

                    # Add combination info
                    normalized_combo['Energy_Source'] = energy_df['Source'].iloc[0] if 'Source' in energy_df.columns else f"Energy_{i}"
                    normalized_combo['Population_Source'] = pop_df['Source'].iloc[0] if 'Source' in pop_df.columns else f"Population_{j}"
                    normalized_combo['Combo_ID'] = f"E{i}_P{j}"

                    all_normalized_results.append(normalized_combo)

        # Check if we have any valid results
        if not all_normalized_results:
            print("\nERROR: No valid data combinations found after filtering!")
            print("Check the input data for zeros, negative values, or missing years.")
            return pd.DataFrame(columns=['Country', 'Year', 'WWI_observed', 'WWI_observed_std', 'WWI_baseline'])

        # Combine all NORMALIZED results
        all_normalized = pd.concat(all_normalized_results, ignore_index=True)

        # Calculate statistics across normalized values
        # For each country-year, calculate statistics across all combinations
        stats = all_normalized.groupby(['Country', 'Year']).agg({
            'WWI_norm': ['median', 'std', 'min', 'max', 'count'],
            'WWI_baseline': 'first'  # Take first baseline (all should be same for a country)
        }).reset_index()

        # Flatten columns
        stats.columns = ['Country', 'Year', 'WWI_median', 'WWI_std', 'WWI_min', 'WWI_max', 'WWI_count', 'WWI_baseline']

        # Remove rows without baseline
        stats = stats.dropna(subset=['WWI_baseline'])

        # Rename for clarity
        stats = stats.rename(columns={
            'WWI_median': 'WWI_observed',
            'WWI_std': 'WWI_observed_std'
        })

        print(f"\nCalculated observed WWI for {stats['Country'].nunique()} countries")
        print(f"Years: {stats['Year'].min()} to {stats['Year'].max()}")
        print(f"Valid combinations: {len(all_normalized_results)}")
        print(f"New method: Normalize FIRST, then calculate statistics")

        return stats[['Country', 'Year', 'WWI_observed', 'WWI_observed_std', 'WWI_baseline']]


# Model calculator
class ModelCalculator:
    """Predicted WWI from the TEF equation (Eq. 3)."""

    @staticmethod
    def calculate_predicted_wwi(parameters: Dict[str, List[pd.DataFrame]],
                            observed_baselines: pd.DataFrame) -> Tuple[pd.DataFrame, List[pd.DataFrame]]:
        """
        Calculate the predicted WWI with the TEF equation (Eq. 3).
        Returns: (summary_data, detailed_data_list)
        """
        print("\n" + "="*60)
        print("CALCULATING PREDICTED WWI")
        print("="*60)

        # Get all file combinations
        gdp_files = parameters.get('gdp', [])
        pop_files = parameters.get('population', [])
        energy_files = parameters.get('energy', [])
        elec_files = parameters.get('electricity', [])

        # Calculate total combinations
        total_combos = len(gdp_files) * len(pop_files) * len(energy_files) * len(elec_files)
        print(f"Running {total_combos} file combinations:")
        print(f"  GDP: {len(gdp_files)} files")
        print(f"  Population: {len(pop_files)} files")
        print(f"  Energy: {len(energy_files)} files")
        print(f"  Electricity: {len(elec_files)} files")

        # Store all results
        all_results = []
        detailed_results = []  # Store detailed data for debugging

        combo_count = 0
        valid_combos = 0

        for i, gdp_df in enumerate(gdp_files):
            for j, pop_df in enumerate(pop_files):
                for k, energy_df in enumerate(energy_files):
                    for l, elec_df in enumerate(elec_files):
                        combo_count += 1
                        # Create unique combo ID
                        combo_id = f"G{i}_P{j}_E{k}_EL{l}"
                        print(f"  Processing combination {combo_count}/{total_combos} ({combo_id})...", end='\r')

                        # Calculate for this combination
                        result = ModelCalculator._calculate_single_combo(
                            gdp_df, pop_df, energy_df, elec_df, observed_baselines, combo_id
                        )

                        if not result.empty:
                            # Add to summary results
                            summary_result = result[['Country', 'Year', 'WWI_predicted']].copy()
                            summary_result['combination_id'] = combo_id
                            all_results.append(summary_result)

                            # Add to detailed results
                            detailed_results.append(result)
                            valid_combos += 1

        print(f"\n  Completed {total_combos} combinations!")
        print(f"  Valid combinations with data: {valid_combos}")

        # Check if we have any valid results
        if not all_results:
            print("\nWARNING: No valid predictions calculated!")
            print("Returning empty dataframes.")
            empty_summary = pd.DataFrame(columns=['Country', 'Year', 'WWI_min', 'WWI_max', 'WWI_median',
                                                'WWI_mean', 'WWI_std', 'WWI_count'])
            return empty_summary, []

        # Combine all summary results
        all_combined = pd.concat(all_results, ignore_index=True)

        # Calculate statistics for each country-year
        stats = all_combined.groupby(['Country', 'Year']).agg({
            'WWI_predicted': ['min', 'max', 'median', 'mean', 'std', 'count']
        }).reset_index()

        # Flatten columns
        stats.columns = ['Country', 'Year', 'WWI_min', 'WWI_max', 'WWI_median',
                        'WWI_mean', 'WWI_std', 'WWI_count']

        print(f"Calculated predicted WWI for {stats['Country'].nunique()} countries")

        return stats, detailed_results

    # IMPORTANT: This method must be defined INSIDE the ModelCalculator class
    @staticmethod
    def _calculate_single_combo(gdp_df: pd.DataFrame, pop_df: pd.DataFrame,
                            energy_df: pd.DataFrame, elec_df: pd.DataFrame,
                            observed_baselines: pd.DataFrame,
                            combo_id: str = "") -> pd.DataFrame:
        """
        Calculate predicted WWI for a single file combination.
        FIXED VERSION with unit checking and Combo_ID.
        """
        # Merge all data
        merged = gdp_df[['Country', 'Year', 'GDP']].copy()

        # Merge other data
        pop_data = pop_df[['Country', 'Year', 'Population']].copy()
        merged = pd.merge(merged, pop_data, on=['Country', 'Year'], how='inner')

        energy_data = energy_df[['Country', 'Year', 'Energy']].copy()
        merged = pd.merge(merged, energy_data, on=['Country', 'Year'], how='inner')

        elec_data = elec_df[['Country', 'Year', 'Electricity']].copy()
        merged = pd.merge(merged, elec_data, on=['Country', 'Year'], how='inner')

        # Remove invalid rows
        merged = merged.dropna(subset=['GDP', 'Population', 'Energy', 'Electricity'])
        merged = merged[
            (merged['GDP'] > 0) &
            (merged['Population'] > 0) &
            (merged['Energy'] > 0) &
            (merged['Electricity'] > 0)
        ]

        if merged.empty:
            return pd.DataFrame()

        # Print sample values
        print(f"\n  Debug for {combo_id}:")
        sample_country = "Usa"
        sample = merged[merged['Country'] == sample_country]
        if not sample.empty:
            print(f"    {sample_country} 2020 values:")
            sample_2020 = sample[sample['Year'] == 2020]
            if not sample_2020.empty:
                row = sample_2020.iloc[0]
                print(f"      GDP: {row['GDP']:,}")
                print(f"      Population: {row['Population']:,}")
                print(f"      Energy: {row['Energy']:,}")
                print(f"      Electricity: {row['Electricity']:,}")

        # Calculate intermediate values
        merged['GDP_per_capita'] = merged['GDP'] / merged['Population']
        merged = merged[merged['GDP_per_capita'] > 1e-10]
        merged['Energy_intensity'] = merged['Energy'] / merged['GDP_per_capita']

        # Get baseline (2020)
        baseline = merged[merged['Year'] == Config.BASELINE_YEAR].copy()
        if baseline.empty:
            return pd.DataFrame()

        baseline = baseline.set_index('Country')

        # Create result
        result = merged.copy()

        # Add source information and COMBO_ID
        # Get source file names
        gdp_source = gdp_df['Source'].iloc[0] if 'Source' in gdp_df.columns else "GDP"
        pop_source = pop_df['Source'].iloc[0] if 'Source' in pop_df.columns else "Population"
        energy_source = energy_df['Source'].iloc[0] if 'Source' in energy_df.columns else "Energy"
        elec_source = elec_df['Source'].iloc[0] if 'Source' in elec_df.columns else "Electricity"

        # Add to result
        result['GDP_source'] = gdp_source
        result['Population_source'] = pop_source
        result['Energy_source'] = energy_source
        result['Electricity_source'] = elec_source
        result['Combo_ID'] = combo_id

        # Initialize prediction columns
        result['WWI_predicted'] = np.nan
        result['comp1'] = np.nan
        result['comp2'] = np.nan
        result['comp3'] = np.nan
        result['wwi_factor'] = np.nan

        # Calculate for each row
        for idx, row in merged.iterrows():
            country = row['Country']
            year = row['Year']

            if country not in baseline.index:
                continue

            try:
                # Get baseline (2020) values
                gdp_2020 = baseline.loc[country, 'GDP']
                energy_2020 = baseline.loc[country, 'Energy']
                pop_2020 = baseline.loc[country, 'Population']
                elec_2020 = baseline.loc[country, 'Electricity']

                # Get current year values
                gdp_t = row['GDP']
                energy_t = row['Energy']
                pop_t = row['Population']
                elec_t = row['Electricity']

                # Skip zeros
                if any(x <= 0 for x in [gdp_2020, energy_2020, pop_2020, elec_2020,
                                    gdp_t, energy_t, pop_t, elec_t]):
                    continue

                # Check for extreme values
                # If values are too extreme, skip or adjust
                gdp_ratio = gdp_2020 / gdp_t
                elec_ratio = elec_2020 / elec_t

                # Skip if ratios are extreme (suggests unit issues)
                if gdp_ratio < 1e-10 or gdp_ratio > 1e10:
                    continue
                if elec_ratio < 1e-10 or elec_ratio > 1e10:
                    continue

                # Calculate GDP per capita
                gdp_per_capita_2020 = gdp_2020 / pop_2020
                gdp_per_capita_t = gdp_t / pop_t

                if gdp_per_capita_2020 <= 0 or gdp_per_capita_t <= 0:
                    continue

                # Calculate energy intensity
                energy_intensity_2020 = energy_2020 / gdp_per_capita_2020
                energy_intensity_t = energy_t / gdp_per_capita_t

                if energy_intensity_2020 <= 0 or energy_intensity_t <= 0:
                    continue

                # TEF equation
                comp1 = (gdp_2020) / (gdp_t)
                comp2 = energy_intensity_t / energy_intensity_2020
                comp3 = elec_2020 / elec_t

                # Skip extreme values
                if any(x < 1e-10 or x > 1e10 for x in [comp1, comp2, comp3]):
                    continue

                wwi_factor = (comp1**0.5) + (comp2) + (comp3)

                # Normalise so that the base year (2020) gives WWI = 1
                # But comp1=1, comp2=1, comp3=1 gives wwi_factor=3
                # So we need to divide by 3
                wwi_predicted = wwi_factor / 3

                if np.isfinite(wwi_predicted):
                    result.loc[idx, 'WWI_predicted'] = wwi_predicted
                    result.loc[idx, 'comp1'] = comp1
                    result.loc[idx, 'comp2'] = comp2
                    result.loc[idx, 'comp3'] = comp3
                    result.loc[idx, 'wwi_factor'] = wwi_factor

            except Exception as e:
                continue

        # Remove NaN predictions
        result = result.dropna(subset=['WWI_predicted'])

        # Add normalized columns for debugging
        if not result.empty:
            for country in result['Country'].unique():
                country_mask = result['Country'] == country
                baseline_mask = country_mask & (result['Year'] == Config.BASELINE_YEAR)

                if result.loc[baseline_mask, 'GDP'].any():
                    gdp_baseline = result.loc[baseline_mask, 'GDP'].values[0]
                    result.loc[country_mask, 'GDP_normalized'] = gdp_baseline / result.loc[country_mask, 'GDP']

                if result.loc[baseline_mask, 'Energy'].any():
                    energy_baseline = result.loc[baseline_mask, 'Energy'].values[0]
                    result.loc[country_mask, 'Energy_normalized'] = energy_baseline / result.loc[country_mask, 'Energy']

                if result.loc[baseline_mask, 'Electricity'].any():
                    elec_baseline = result.loc[baseline_mask, 'Electricity'].values[0]
                    result.loc[country_mask, 'Electricity_normalized'] = elec_baseline / result.loc[country_mask, 'Electricity']

        return result

# Plotter
class Plotter:
    """Plots of observed and predicted WWI."""

    @staticmethod
    def create_plots(observed_data: pd.DataFrame, predicted_data: pd.DataFrame,
                    countries: List[str], subplot_rows: int, subplot_cols: int):
        """
        Create multiple figures with subplots for each country.

        Each subplot shows:
        - Observed: points with median ± std error bars
        - Predicted: median line with min-max shadow
        """
        print("\n" + "="*60)
        print("CREATING PLOTS")
        print("="*60)

        # Filter to requested countries
        available_countries = [c for c in countries if c in observed_data['Country'].unique()]

        if not available_countries:
            print("No requested countries found in data!")
            return

        print(f"Plotting {len(available_countries)} countries")

        # Calculate number of figures needed
        plots_per_figure = subplot_rows * subplot_cols
        num_figures = int(np.ceil(len(available_countries) / plots_per_figure))

        for fig_num in range(num_figures):
            start_idx = fig_num * plots_per_figure
            end_idx = min((fig_num + 1) * plots_per_figure, len(available_countries))
            countries_in_fig = available_countries[start_idx:end_idx]

            # Create figure
            fig, axes = plt.subplots(subplot_rows, subplot_cols,
                                    figsize=(subplot_cols * 4, subplot_rows * 3))

            # Handle axes formatting
            if subplot_rows == 1 and subplot_cols == 1:
                axes_flat = [axes]
            elif subplot_rows == 1 or subplot_cols == 1:
                axes_flat = axes
            else:
                axes_flat = axes.flatten()

            # Plot each country
            for idx, country in enumerate(countries_in_fig):
                ax = axes_flat[idx]

                try:
                    # Get data for this country
                    obs_country = observed_data[observed_data['Country'] == country].sort_values('Year')
                    pred_country = predicted_data[predicted_data['Country'] == country].sort_values('Year')

                    if obs_country.empty and pred_country.empty:
                        ax.set_title(f"{country}\nNo Data", fontsize=10)
                        continue

                    # Plot predicted
                    if not pred_country.empty:
                        years_pred = pred_country['Year'].values

                        # Median line
                        ax.plot(years_pred, pred_country['WWI_median'].values,
                            color='#1B9E77', linewidth=2, label='Predicted (Median)')

                        # Min-max shadow
                        ax.fill_between(years_pred,
                                       pred_country['WWI_min'].values,
                                       pred_country['WWI_max'].values,
                                       alpha=0.3, color='#A6DCC7', label='Predicted Range')

                    # Plot observed
                    if not obs_country.empty:
                        years_obs = obs_country['Year'].values

                        # Points with error bars
                        if 'WWI_observed_std' in obs_country.columns:
                            errors = obs_country['WWI_observed_std'].values
                            ax.errorbar(years_obs, obs_country['WWI_observed'].values,
                                    yerr=errors, fmt='o', color='#1F3A5F', markersize=5,
                                    capsize=3, elinewidth=1, label='Observed ± 1 sd')
                        else:
                            ax.plot(years_obs, obs_country['WWI_observed'].values,
                                'o', color='#1F3A5F', markersize=5, label='Observed')

                    # Customize plot
                    if country=="Usa":
                        ax.set_title(f"USA", fontsize=11, fontweight='bold')
                    elif country=="Uae":
                        ax.set_title(f"UAE", fontsize=11, fontweight='bold')
                    elif country=="Uk":
                        ax.set_title(f"UK", fontsize=11, fontweight='bold')
                    elif country=="Saudi":
                        ax.set_title(f"Saudi Arabia", fontsize=11, fontweight='bold')
                    else:
                        ax.set_title(f"{country}", fontsize=11, fontweight='bold')
                    row_idx = idx // subplot_cols
                    if row_idx == subplot_rows - 1:
                        ax.set_xlabel('Year', fontsize=9)

                    # Only add y-label to leftmost plots
                    if idx % subplot_cols == 0:
                        ax.set_ylabel('Normalized WWI', fontsize=10)

                    #ax.grid(True, alpha=0.3, linestyle='--')

                    # Add legend to first subplot only
                    #if idx == 0:
                    #    ax.legend(fontsize=14, loc='best')

                    # Set y-axis limits
                    all_values = []
                    if not pred_country.empty:
                        all_values.extend(pred_country['WWI_min'].values)
                        all_values.extend(pred_country['WWI_max'].values)
                    if not obs_country.empty:
                        all_values.extend(obs_country['WWI_observed'].values)

                    if all_values:
                        valid_vals = [v for v in all_values if not np.isnan(v)]
                        if valid_vals:
                            y_min = max(0, min(valid_vals) * 0.8)
                            y_max = max(valid_vals) * 1.2
                            ax.set_ylim(y_min, y_max)

                except Exception as e:
                    ax.set_title(f"{country}\nError", fontsize=10)
                    ax.text(0.5, 0.5, f"Plotting error",
                           ha='center', va='center', transform=ax.transAxes, fontsize=8)
                    print(f"Error plotting {country}: {e}")

            # Hide unused subplots
            for idx in range(len(countries_in_fig), len(axes_flat)):
                axes_flat[idx].set_visible(False)

            # Figure title
            plt.suptitle(f"WWI Uncertainty Analysis - Figure {fig_num + 1}/{num_figures}",
                        fontsize=14, y=1.02)

            plt.tight_layout()
            plt.show()

            # Save figure if needed
            if Config.EXPORT_DEBUG:
                os.makedirs(Config.DEBUG_DIR, exist_ok=True)
                fig_path = os.path.join(Config.DEBUG_DIR, f"figure_{fig_num + 1}.png")
                fig.savefig(fig_path, dpi=300, bbox_inches='tight')
                print(f"  Saved figure {fig_num + 1} to {fig_path}")


# Data exporter
# Data exporter (detailed)
class DataExporter:
    """Exports all data for debugging with detailed predicted value breakdown."""

    @staticmethod
    def export_all_data(observed_data: pd.DataFrame, predicted_data: pd.DataFrame,
                    parameters: Dict[str, List[pd.DataFrame]],
                    detailed_predictions: List[pd.DataFrame] = None):
        """Export all data to Excel files with detailed debugging."""
        if not Config.EXPORT_DEBUG:
            return

        print("\n" + "="*60)
        print("EXPORTING DATA WITH DETAILED DEBUGGING")
        print("="*60)

        # Create output directory
        os.makedirs(Config.DEBUG_DIR, exist_ok=True)

        # 1. Export observed data
        obs_path = os.path.join(Config.DEBUG_DIR, "01_observed_wwi.xlsx")
        observed_data.to_excel(obs_path, index=False)
        print(f"Observed WWI: {obs_path}")

        # 2. Export predicted summary
        pred_path = os.path.join(Config.DEBUG_DIR, "02_predicted_wwi_summary.xlsx")
        predicted_data.to_excel(pred_path, index=False)
        print(f"Predicted WWI summary: {pred_path}")

        # 3. Export detailed predicted calculations if available
        if detailed_predictions and len(detailed_predictions) > 0:
            detailed_dir = os.path.join(Config.DEBUG_DIR, "detailed_predictions")
            os.makedirs(detailed_dir, exist_ok=True)

            print(f"\nExporting detailed predictions for each combination:")

            # Combine all detailed results
            all_detailed = pd.concat(detailed_predictions, ignore_index=True)

            # Check what columns we have for debugging
            print(f"  Available columns in detailed data: {list(all_detailed.columns)}")

            # Export combined detailed results
            detailed_path = os.path.join(detailed_dir, "all_combinations_detailed.xlsx")
            all_detailed.to_excel(detailed_path, index=False)
            print(f"  All combinations detailed: {detailed_path}")

            # Export summary by combination - FIXED: Check if Combo_ID exists
            if 'Combo_ID' in all_detailed.columns:
                combo_summary = all_detailed.groupby(['Combo_ID', 'Country']).agg({
                    'Year': 'count',
                    'WWI_predicted': ['min', 'max', 'mean']
                }).reset_index()
                # Flatten multi-level columns
                combo_summary.columns = ['Combo_ID', 'Country', 'Year_Count', 'WWI_min', 'WWI_max', 'WWI_mean']
                combo_summary_path = os.path.join(detailed_dir, "combination_summary.xlsx")
                combo_summary.to_excel(combo_summary_path, index=False)
                print(f"  Combination summary: {combo_summary_path}")
            else:
                print(f"  No 'Combo_ID' column found in detailed data")
                # Try alternative grouping if Combo_ID doesn't exist
                if 'GDP_source' in all_detailed.columns and 'Energy_source' in all_detailed.columns:
                    # Group by source combinations instead
                    combo_summary = all_detailed.groupby(['GDP_source', 'Population_source',
                                                        'Energy_source', 'Electricity_source', 'Country']).agg({
                        'Year': 'count',
                        'WWI_predicted': ['min', 'max', 'mean']
                    }).reset_index()
                    combo_summary.columns = ['GDP_source', 'Population_source', 'Energy_source',
                                            'Electricity_source', 'Country', 'Year_Count',
                                            'WWI_min', 'WWI_max', 'WWI_mean']
                    combo_summary_path = os.path.join(detailed_dir, "combination_summary.xlsx")
                    combo_summary.to_excel(combo_summary_path, index=False)
                    print(f"  Combination summary (by sources): {combo_summary_path}")

            # Export first few combinations separately for easier debugging
            for i, combo_df in enumerate(detailed_predictions[:5]):  # First 5 combinations
                if not combo_df.empty:
                    # Create a combo identifier if Combo_ID doesn't exist
                    if 'Combo_ID' not in combo_df.columns:
                        # Try to create one from source columns
                        if all(col in combo_df.columns for col in ['GDP_source', 'Population_source',
                                                                'Energy_source', 'Electricity_source']):
                            gdp_src = combo_df['GDP_source'].iloc[0][:10] if len(combo_df['GDP_source'].iloc[0]) > 10 else combo_df['GDP_source'].iloc[0]
                            pop_src = combo_df['Population_source'].iloc[0][:10] if len(combo_df['Population_source'].iloc[0]) > 10 else combo_df['Population_source'].iloc[0]
                            energy_src = combo_df['Energy_source'].iloc[0][:10] if len(combo_df['Energy_source'].iloc[0]) > 10 else combo_df['Energy_source'].iloc[0]
                            elec_src = combo_df['Electricity_source'].iloc[0][:10] if len(combo_df['Electricity_source'].iloc[0]) > 10 else combo_df['Electricity_source'].iloc[0]
                            combo_id = f"{gdp_src}_{pop_src}_{energy_src}_{elec_src}"
                        else:
                            combo_id = f"combination_{i+1}"
                    else:
                        combo_id = combo_df['Combo_ID'].iloc[0]

                    combo_path = os.path.join(detailed_dir, f"{combo_id}_detailed.xlsx")
                    combo_df.to_excel(combo_path, index=False)
                    print(f"  Combination {combo_id}: {len(combo_df)} rows")

        # 4. Export raw parameter data with normalization calculations
        raw_dir = os.path.join(Config.DEBUG_DIR, "raw_parameters_normalized")
        os.makedirs(raw_dir, exist_ok=True)

        print(f"\nExporting raw parameters with normalization:")

        for param_name, param_list in parameters.items():
            if param_list:
                # Calculate normalization for each file
                for file_idx, param_df in enumerate(param_list):
                    if 'Country' in param_df.columns and 'Year' in param_df.columns:
                        # Get value column name
                        value_cols = [c for c in param_df.columns if c not in ['Country', 'Year', 'Source']]
                        if value_cols:
                            value_col = value_cols[0]  # Take first non-standard column

                            # Calculate baseline values
                            baseline_df = param_df[param_df['Year'] == Config.BASELINE_YEAR][['Country', value_col]]
                            baseline_df = baseline_df.rename(columns={value_col: f'{value_col}_baseline'})

                            # Merge and normalize
                            normalized_df = pd.merge(param_df, baseline_df, on='Country', how='left')
                            normalized_df[f'{value_col}_normalized'] = normalized_df[f'{value_col}_baseline'] / normalized_df[value_col]

                            # Export
                            file_name = os.path.basename(param_df['Source'].iloc[0]) if 'Source' in param_df.columns else f"file_{file_idx}"
                            # Clean filename for safety
                            file_name = "".join(c for c in file_name if c.isalnum() or c in ['_', '.', '-'])[:50]
                            param_path = os.path.join(raw_dir, f"{param_name}_{file_name}_normalized.xlsx")
                            normalized_df.to_excel(param_path, index=False)
                            print(f"  {param_name:15s}: File {file_idx+1}: {param_path}")

        # 5. Export comparison: observed vs predicted for key countries
        if not observed_data.empty and not predicted_data.empty:
            # Select first 10 countries for comparison
            countries_to_compare = observed_data['Country'].unique()[:10]

            comparison_data = []
            for country in countries_to_compare:
                obs_country = observed_data[observed_data['Country'] == country]
                pred_country = predicted_data[predicted_data['Country'] == country]

                # Merge observed and predicted
                if not obs_country.empty and not pred_country.empty:
                    comparison = pd.merge(
                        obs_country[['Year', 'WWI_observed', 'WWI_observed_std']],
                        pred_country[['Year', 'WWI_median', 'WWI_min', 'WWI_max']],
                        on='Year', how='inner'
                    )
                    comparison['Country'] = country
                    comparison_data.append(comparison)

            if comparison_data:
                comparison_df = pd.concat(comparison_data, ignore_index=True)
                # Reorder columns
                comparison_df = comparison_df[['Country', 'Year', 'WWI_observed', 'WWI_observed_std',
                                            'WWI_median', 'WWI_min', 'WWI_max']]
                comparison_path = os.path.join(Config.DEBUG_DIR, "03_observed_vs_predicted_comparison.xlsx")
                comparison_df.to_excel(comparison_path, index=False)
                print(f"\nObserved vs Predicted comparison: {comparison_path}")

        # 6. Export configuration
        config_data = {
            'Parameter': ['BASELINE_YEAR', 'START_YEAR', 'END_YEAR', 'Energy_Files', 'Population_Files', 'GDP_Files'],
            'Value': [Config.BASELINE_YEAR, Config.START_YEAR, Config.END_YEAR,
                    len(parameters.get('energy', [])), len(parameters.get('population', [])),
                    len(parameters.get('gdp', []))]
        }
        config_df = pd.DataFrame(config_data)
        config_path = os.path.join(Config.DEBUG_DIR, "04_configuration.xlsx")
        config_df.to_excel(config_path, index=False)
        print(f"\nConfiguration: {config_path}")

        print(f"\nAll data exported to: {Config.DEBUG_DIR}")
        print("="*60)


# Main

def main_with_country_categories():
    """Main analysis pipeline with categorized predicted vs observed plots."""
    print("="*70)
    print("WATER INTENSITY UNCERTAINTY ANALYSIS")
    print("WITH COUNTRY CATEGORY CLASSIFICATION")
    print("="*70)

    try:
        # Step 1: Load all data
        print("\n[1/6] LOADING DATA...")
        parameters = DataLoader.load_all_data()

        # Check we have all required data
        required = ['water', 'population', 'gdp', 'energy', 'electricity']
        missing = [r for r in required if r not in parameters or not parameters[r]]
        if missing:
            print(f"ERROR: Missing required data: {missing}")
            return

        # Step 2: Calculate observed WWI
        print("\n[2/6] CALCULATING OBSERVED WWI...")
        observed_data = ObservedCalculator.calculate_observed_wwi(parameters)

        if observed_data.empty:
            print("ERROR: No observed data calculated!")
            return

        # Step 3: Calculate predicted WWI
        print("\n[3/6] CALCULATING PREDICTED WWI...")
        predicted_summary, detailed_predictions = ModelCalculator.calculate_predicted_wwi(
            parameters, observed_data[['Country', 'WWI_baseline']].drop_duplicates()
        )

        # Step 4: Create time series plots
        print("\n[4/6] CREATING TIME SERIES PLOTS...")
        plotter = Plotter()
        plotter.create_plots(observed_data, predicted_summary, Config.COUNTRIES_TO_PLOT,
                            Config.SUBPLOT_ROWS, Config.SUBPLOT_COLS)

        print("\n[5/6] CREATING CATEGORIZED PREDICTED VS OBSERVED PLOTS...")


        # Step 5: Export data with detailed debugging
        print("\n[6/6] EXPORTING DATA WITH DETAILED DEBUGGING...")
        exporter = DataExporter()
        exporter.export_all_data(observed_data, predicted_summary, parameters, detailed_predictions)

        print("\n" + "="*70)
        print("ANALYSIS COMPLETE WITH COUNTRY CATEGORY PLOTS!")
        print("="*70)


    except Exception as e:
        print(f"\nERROR: {str(e)}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main_with_country_categories()
