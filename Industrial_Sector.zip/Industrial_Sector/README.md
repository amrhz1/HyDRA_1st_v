# Industrial sector

Industrial and power-plant water withdrawal and consumption, 1990–2025 (Sect. 2.1 of the paper).

## Running the model

1. `TEF_Calculator/TEF_Calculator.py` computes the techno-economic factor (TEF, Eq. 3) for every country and year from
   the industrial water use, population, GDP, energy and electricity data in its subfolders. The result,
   `TEF_Calculator/output/02_predicted_wwi_summary.xlsx`, is included, so this step can be skipped.
2. `Simple_Allocation.py` multiplies the production of each subsector by its withdrawal and consumption intensities
   (Table 3) and by the TEF, and places the water at the plants, oil fields, mining areas or industrial areas of each
   country. The results are written to `Model_Output/`.

The intensities are set at the top of `Simple_Allocation.py` (`SUBSECTOR_WITHDRAWAL_CONSTANTS`,
`SUBSECTOR_CONSUMPTION_CONSTANTS`, `FOOD_BEV_WITHDRAWAL_CONSTANTS`, `SEA_WATER_COOLING_RATES_WITHDRAWAL` and the power
generation coefficients). Oil extraction does not use the TEF.

## Inputs

`Sub_Sectors/<subsector>/model_input_data/production.xlsx`: annual national production, one column per country.

| Subsector | Unit of production |
|---|---|
| Power_Generation | MWh |
| Petro_Ref | thousand m³ of crude oil |
| PetroChem | Mt |
| Steel, Cement | thousand t |
| Aluminium, Paper_Pulp, Mining, Potash | t |
| Food_Bev | thousand US$ of value added |
| Oil_Extraction | m³ of oil |

`Sub_Sectors/<subsector>/plant_capacity_location/<country>.xlsx`: one row per year and one column per plant. Column
names are the plant coordinates (latitude, longitude) and values are capacities. National production is divided among
the plants in proportion to their capacity in each year. The sources of the capacities are listed in
`Sub_Sectors/References.xlsx`.

`Sub_Sectors/Power_Generation/plant_capacity_location/processed/`: capacities of the power plants
(`<country>.xlsx`) and their cooling type (`<country>_cooling_types.xlsx`: sea, fresh, reused, dry or renewable).

`Sub_Sectors/Mining/Mining_tif/`: mining areas of each country, derived from the global mining-area data of Maus et
al. (2020) with `mining_tif_creator.py`.

`Sub_Sectors/Other/`: industrial areas of each country. Food and beverage, paper and pulp and other manufacturing are
distributed over these areas in proportion to their extent. The files are compressed GeoTIFFs (DEFLATE, lossless).

`Spatial_Data/All_zero_clip.tif`: template grid of the study domain (0.000833°, EPSG:4326).

`Spatial_Data/Natural_Earth/`: not included; see the README in the main folder.

## Outputs

`Model_Output/detailed_outputs/water_allocation_<year>.xlsx`: one row per plant or allocation point, with subsector,
country, coordinates, water type (freshwater, mining, seawater cooling, power: sea, fresh, reused or dry),
withdrawal and consumption (Mm³ yr⁻¹) and distance to the coast.

`Model_Output/detailed_outputs/summary_<year>.xlsx`: totals by subsector.

`Model_Output/pngs/`: maps of each year. Gridded output (GeoTIFF) is written when `WRITE_TIF_OUTPUT = True`.

## Validation

`Validation/` contains the workbooks behind the baseline withdrawal intensities of Table 3: basic metals
(`Water_per_Metal.xlsx`), paper and pulp (`Water_per_Paper_Pulp.xlsx`), food and beverage
(`Water_per_Value_Added_Food_Beverage.xlsx`) and petro-refining (`Water_per_Oil_Refined.xlsx`). Each workbook holds the
input data and computes the intensities and their statistics with Excel formulas.
